-- ============================================================================
-- core helpers, STANDALONE MODE (a module running on its own database).
--
-- Same function names/signatures as migrations/0001_core_rls_helpers.sql, so
-- module RLS policies are portable byte-for-byte. Reads ONLY JWT claims
-- (request.jwt.claims), as set by PostgREST from a core-issued / OAuth token,
-- or by the module server per transaction:
--
--   {"sub": "<user or client id>", "tid": "<tenant uuid>",
--    "scope": "orders:read guests:admin", "op_roles": ["manager"],
--    "op_modules": ["guests"], "op_admin": false}
--
-- Apply once to the standalone database (requires the `auth.uid()` function,
-- present on any Supabase project). Do NOT apply to the shared project.
-- ============================================================================

create schema if not exists core;

create or replace function core.claims() returns jsonb language sql stable set search_path = '' as $$
  select coalesce(nullif(current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb);
$$;

create or replace function core.claim_tenant_id() returns uuid language sql stable set search_path = '' as $$
  select case
    when (core.claims() ->> 'tid') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      then (core.claims() ->> 'tid')::uuid
  end;
$$;

create or replace function core.claim_scopes() returns text[] language sql stable set search_path = '' as $$
  select coalesce(string_to_array(nullif(core.claims() ->> 'scope', ''), ' '), '{}'::text[]);
$$;

create or replace function core.claim_array(key text) returns text[] language sql stable set search_path = '' as $$
  select coalesce(array(select jsonb_array_elements_text(core.claims() -> key)), '{}'::text[]);
$$;

create or replace function core.current_user_id() returns uuid language sql stable set search_path = '' as $$
  select case
    when (core.claims() ->> 'sub') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      then (core.claims() ->> 'sub')::uuid
  end;
$$;

create or replace function core.scope_matches(granted text[], required text)
returns boolean language sql immutable set search_path = '' as $$
  select exists (
    select 1 from unnest(granted) as g(s)
    where g.s = '*'
       or g.s = required
       or (split_part(g.s, ':', 2) = '*' and split_part(g.s, ':', 1) = split_part(required, ':', 1))
       or (split_part(g.s, ':', 1) = '*' and split_part(g.s, ':', 2) = split_part(required, ':', 2))
       or (split_part(g.s, ':', 2) = split_part(required, ':', 2)
           and split_part(required, ':', 1) like split_part(g.s, ':', 1) || '.%')
  );
$$;

create or replace function core.is_platform_admin() returns boolean language sql stable set search_path = '' as $$
  select coalesce((core.claims() ->> 'op_admin')::boolean, false);
$$;

create or replace function core.user_roles(target_tenant_id uuid) returns text[] language sql stable set search_path = '' as $$
  select case when core.claim_tenant_id() = target_tenant_id then core.claim_array('op_roles') else '{}'::text[] end;
$$;

create or replace function core.is_tenant_member(target_tenant_id uuid) returns boolean language sql stable set search_path = '' as $$
  select coalesce(core.claim_tenant_id() = target_tenant_id, false);
$$;

create or replace function core.is_member(target_tenant_id uuid) returns boolean language sql stable set search_path = '' as $$
  select core.is_tenant_member(target_tenant_id);
$$;

create or replace function core.has_tenant_role(target_tenant_id uuid, allowed_roles text[])
returns boolean language sql stable set search_path = '' as $$
  select core.user_roles(target_tenant_id) && allowed_roles;
$$;

create or replace function core.has_scope(target_tenant_id uuid, required_scope text)
returns boolean language sql stable set search_path = '' as $$
  select coalesce(core.claim_tenant_id() = target_tenant_id and core.scope_matches(core.claim_scopes(), required_scope), false);
$$;

create or replace function core.current_tenant_ids() returns setof uuid language sql stable set search_path = '' as $$
  select core.claim_tenant_id() where core.claim_tenant_id() is not null;
$$;

create or replace function core.module_enabled(target_tenant_id uuid, module text)
returns boolean language sql stable set search_path = '' as $$
  select coalesce(core.claim_tenant_id() = target_tenant_id and module = any(core.claim_array('op_modules')), false);
$$;

revoke all on all functions in schema core from public;
do $$
declare r text;
begin
  foreach r in array array['authenticated', 'service_role'] loop
    if exists (select from pg_roles where rolname = r) then
      execute format('grant usage on schema core to %I', r);
      execute format('grant execute on all functions in schema core to %I', r);
    end if;
  end loop;
end;
$$;
