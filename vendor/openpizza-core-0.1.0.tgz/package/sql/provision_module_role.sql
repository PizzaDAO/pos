-- ============================================================================
-- Provision a module's database role + schema (run ONCE per module by the
-- project owner, e.g. in the Supabase SQL editor). Not a migration: it touches
-- project-level objects (roles), which openpizza-migrate refuses by design.
--
-- Replace :module (e.g. guests) and :password before running, or use psql:
--   psql "$DATABASE_URL" -v module=guests -v password="'…'" -f provision_module_role.sql
-- ============================================================================

-- 1. Login role for the module's server code (connect through the pooler).
--    No BYPASSRLS, no grants on public.
create role mod_:module login password :password noinherit nobypassrls;

-- 2. The module's schema, owned by its role.
create schema if not exists :module authorization mod_:module;

-- 3. May call core helpers, nothing else in core.
grant usage on schema core to mod_:module;
grant execute on all functions in schema core to mod_:module;

-- 4. Explicitly nothing on public (POS) — belt and braces.
revoke all on schema public from mod_:module;

-- 5. Browser access (optional): expose the schema to PostgREST in project
--    settings, then grant table privileges to `authenticated` in the module's
--    own migrations (RLS still applies).
