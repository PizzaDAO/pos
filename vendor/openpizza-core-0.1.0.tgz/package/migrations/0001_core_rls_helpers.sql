-- ============================================================================
-- core 0001: shared tenancy/RLS helpers for every module schema (SHARED MODE).
--
-- Applied with:  openpizza-migrate up --core --url $DATABASE_URL
--
-- Module RLS policies call ONLY these `core.*` functions, never `public.*`:
--   core.is_tenant_member(tenant uuid)            -> boolean
--   core.has_tenant_role(tenant uuid, roles text[])-> boolean
--   core.has_scope(tenant uuid, scope text)        -> boolean
--   core.is_platform_admin()                       -> boolean
--   core.current_tenant_ids()                      -> setof uuid
--   core.module_enabled(tenant uuid, module text)  -> boolean
--   core.current_user_id()                         -> uuid
--
-- Shared mode: wraps POS's public.memberships / public.platform_admins, plus
-- core.member_grants (new roles: employee, driver, dispatcher,
-- catering_manager — kept OUT of POS's membership_role enum so they get no POS
-- back-office access) and machine/module claims set per transaction:
--   select set_config('request.jwt.claims', '{"tid":"<uuid>","scope":"orders:read"}', true);
--
-- Standalone mode: apply sql/standalone/core_helpers_jwt.sql instead (same
-- function names, reads only JWT claims), so module policies are portable.
--
-- All helpers: SECURITY DEFINER, `set search_path = ''`, owner must be
-- SUPERUSER/BYPASSRLS (as POS's helpers), EXECUTE revoked from PUBLIC.
-- ============================================================================

do $$
begin
  if to_regclass('public.memberships') is null or to_regclass('public.platform_admins') is null then
    raise exception 'core 0001 (shared mode) needs POS tenancy tables public.memberships + public.platform_admins. For a standalone module database apply sql/standalone/core_helpers_jwt.sql instead.';
  end if;
  if not exists (select from pg_roles where rolname = current_user and (rolsuper or rolbypassrls)) then
    raise exception 'core 0001 must be applied by a SUPERUSER/BYPASSRLS role (SECURITY DEFINER helpers read FORCE-RLS tables)';
  end if;
end;
$$;

create schema if not exists core;
comment on schema core is 'Open Pizza core: shared tenancy/RLS helpers and registry. Owned by the core repo; modules may only CALL these functions.';

-- ----------------------------------------------------------------------------
-- Tables
-- ----------------------------------------------------------------------------

-- Extra (non-POS) roles per tenant user, optionally scoped to a module/locations.
create table if not exists core.member_grants (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  user_id uuid not null,
  role text not null check (role ~ '^[a-z][a-z0-9_]*$'),
  module text null check (module is null or module ~ '^[a-z][a-z0-9_]*$'),
  location_ids uuid[] null,
  created_by uuid null,
  created_at timestamptz not null default now()
);
create unique index if not exists member_grants_unique
  on core.member_grants (tenant_id, user_id, role, coalesce(module, ''));
create index if not exists member_grants_user on core.member_grants (user_id);

-- Role -> scope bundles (mirror of ROLE_SCOPES in @openpizza/core auth/roles.ts).
create table if not exists core.role_scopes (
  role text not null,
  scope text not null,
  primary key (role, scope)
);

-- Module enablement per tenant (authoritative for MODULES; POS tiers stay in POS).
create table if not exists core.tenant_modules (
  tenant_id uuid not null,
  module_key text not null check (module_key ~ '^[a-z][a-z0-9_]*$'),
  status text not null check (status in ('enabled', 'trial', 'disabled', 'suspended')),
  source text not null default 'plan' check (source in ('plan', 'addon', 'comp', 'external')),
  plan_ref text null,
  limits jsonb not null default '{}'::jsonb,
  config jsonb not null default '{}'::jsonb,
  enabled_at timestamptz null,
  trial_ends_at timestamptz null,
  updated_at timestamptz not null default now(),
  primary key (tenant_id, module_key)
);

insert into core.role_scopes (role, scope) values
  ('owner', '*'),
  ('manager', 'tenant:read'), ('manager', 'locations:read'), ('manager', 'locations:write'),
  ('manager', 'menu:read'), ('manager', 'menu:write'), ('manager', 'menu.availability:write'),
  ('manager', 'orders:read'), ('manager', 'orders:write'), ('manager', 'quotes:write'),
  ('manager', 'payments:read'), ('manager', 'payments:write'), ('manager', 'customers:read'),
  ('manager', 'customers:write'), ('manager', 'staff:read'), ('manager', 'staff:write'),
  ('manager', 'drawer_sessions:read'), ('manager', 'deliveries:read'), ('manager', 'deliveries:write'),
  ('manager', 'sales:read'), ('manager', 'events:subscribe'), ('manager', 'events:publish'),
  ('manager', 'entitlements:read'), ('manager', '*:admin'), ('manager', '*:read'), ('manager', '*:write'),
  ('cashier', 'tenant:read'), ('cashier', 'locations:read'), ('cashier', 'menu:read'),
  ('cashier', 'menu.availability:write'), ('cashier', 'orders:read'), ('cashier', 'orders:write'),
  ('cashier', 'quotes:write'), ('cashier', 'payments:read'), ('cashier', 'payments:write'),
  ('cashier', 'customers:read'), ('cashier', 'customers:write'), ('cashier', 'staff:read'),
  ('cashier', 'drawer_sessions:read'), ('cashier', 'deliveries:read'),
  ('kitchen', 'tenant:read'), ('kitchen', 'locations:read'), ('kitchen', 'menu:read'),
  ('kitchen', 'menu.availability:write'), ('kitchen', 'orders:read'), ('kitchen', 'staff:read'),
  ('kitchen', 'kitchen:read'), ('kitchen', 'kitchen:write'),
  ('employee', 'tenant:read'), ('employee', 'locations:read'), ('employee', 'workforce:self'),
  ('driver', 'tenant:read'), ('driver', 'locations:read'), ('driver', 'orders:read'),
  ('driver', 'deliveries:read'), ('driver', 'deliveries:write'), ('driver', 'driver:self'),
  ('dispatcher', 'tenant:read'), ('dispatcher', 'locations:read'), ('dispatcher', 'orders:read'),
  ('dispatcher', 'customers:read'), ('dispatcher', 'staff:read'), ('dispatcher', 'deliveries:read'),
  ('dispatcher', 'deliveries:write'), ('dispatcher', 'driver:read'), ('dispatcher', 'driver:write'),
  ('catering_manager', 'tenant:read'), ('catering_manager', 'locations:read'), ('catering_manager', 'menu:read'),
  ('catering_manager', 'orders:read'), ('catering_manager', 'orders:write'), ('catering_manager', 'quotes:write'),
  ('catering_manager', 'payments:read'), ('catering_manager', 'payments:write'),
  ('catering_manager', 'customers:read'), ('catering_manager', 'customers:write'),
  ('catering_manager', 'sales:read'), ('catering_manager', 'catering:read'),
  ('catering_manager', 'catering:write'), ('catering_manager', 'catering:admin')
on conflict do nothing;

-- ----------------------------------------------------------------------------
-- Claim helpers (module DB roles set request.jwt.claims per transaction)
-- ----------------------------------------------------------------------------

create or replace function core.claims()
returns jsonb
language sql
stable
set search_path = ''
as $$
  select coalesce(nullif(current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb);
$$;

create or replace function core.claim_tenant_id()
returns uuid
language sql
stable
set search_path = ''
as $$
  select case
    when (core.claims() ->> 'tid') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      then (core.claims() ->> 'tid')::uuid
    else null
  end;
$$;

create or replace function core.claim_scopes()
returns text[]
language sql
stable
set search_path = ''
as $$
  select coalesce(string_to_array(nullif(core.claims() ->> 'scope', ''), ' '), '{}'::text[]);
$$;

create or replace function core.current_user_id()
returns uuid
language sql
stable
set search_path = ''
as $$
  select auth.uid();
$$;

-- Does any granted scope cover `required`? Mirrors hasScopes() in roles.ts:
--   '*', exact, '<resource>:*', '*:<action>', and 'menu:write' ⊇ 'menu.availability:write'.
create or replace function core.scope_matches(granted text[], required text)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select exists (
    select 1
    from unnest(granted) as g(s)
    where g.s = '*'
       or g.s = required
       or (split_part(g.s, ':', 2) = '*' and split_part(g.s, ':', 1) = split_part(required, ':', 1))
       or (split_part(g.s, ':', 1) = '*' and split_part(g.s, ':', 2) = split_part(required, ':', 2))
       or (split_part(g.s, ':', 2) = split_part(required, ':', 2)
           and split_part(required, ':', 1) like split_part(g.s, ':', 1) || '.%')
  );
$$;

-- ----------------------------------------------------------------------------
-- Tenancy helpers
-- ----------------------------------------------------------------------------

create or replace function core.is_platform_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (select 1 from public.platform_admins pa where pa.user_id = auth.uid());
$$;

-- Every role the current user holds in a tenant (POS membership + core grants).
create or replace function core.user_roles(target_tenant_id uuid)
returns text[]
language sql
stable
security definer
set search_path = ''
as $$
  select coalesce(array_agg(distinct r), '{}'::text[])
  from (
    select m.role::text as r
      from public.memberships m
     where m.tenant_id = target_tenant_id and m.user_id = auth.uid()
    union all
    select g.role
      from core.member_grants g
     where g.tenant_id = target_tenant_id and g.user_id = auth.uid()
  ) roles;
$$;

create or replace function core.is_tenant_member(target_tenant_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select target_tenant_id is not null and (
    coalesce(core.claim_tenant_id() = target_tenant_id, false)
    or exists (
      select 1 from public.memberships m
       where m.tenant_id = target_tenant_id and m.user_id = auth.uid()
    )
    or exists (
      select 1 from core.member_grants g
       where g.tenant_id = target_tenant_id and g.user_id = auth.uid()
    )
  );
$$;

-- Alias used in plans/core.md.
create or replace function core.is_member(target_tenant_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select core.is_tenant_member(target_tenant_id);
$$;

create or replace function core.has_tenant_role(target_tenant_id uuid, allowed_roles text[])
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select core.user_roles(target_tenant_id) && allowed_roles;
$$;

create or replace function core.has_scope(target_tenant_id uuid, required_scope text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select target_tenant_id is not null and (
    coalesce(core.claim_tenant_id() = target_tenant_id and core.scope_matches(core.claim_scopes(), required_scope), false)
    or core.scope_matches(
      coalesce(
        (select array_agg(rs.scope) from core.role_scopes rs where rs.role = any(core.user_roles(target_tenant_id))),
        '{}'::text[]
      ),
      required_scope
    )
  );
$$;

create or replace function core.current_tenant_ids()
returns setof uuid
language sql
stable
security definer
set search_path = ''
as $$
  select m.tenant_id from public.memberships m where m.user_id = auth.uid()
  union
  select g.tenant_id from core.member_grants g where g.user_id = auth.uid()
  union
  select core.claim_tenant_id() where core.claim_tenant_id() is not null;
$$;

create or replace function core.module_enabled(target_tenant_id uuid, module text)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from core.tenant_modules tm
     where tm.tenant_id = target_tenant_id
       and tm.module_key = module
       and tm.status in ('enabled', 'trial')
  );
$$;

-- ----------------------------------------------------------------------------
-- RLS on core tables (default deny; FORCE so the owner is not exempt)
-- ----------------------------------------------------------------------------

alter table core.member_grants enable row level security;
alter table core.member_grants force row level security;
alter table core.role_scopes enable row level security;
alter table core.role_scopes force row level security;
alter table core.tenant_modules enable row level security;
alter table core.tenant_modules force row level security;

drop policy if exists member_grants_select on core.member_grants;
create policy member_grants_select on core.member_grants
  for select using (
    user_id = auth.uid()
    or core.has_tenant_role(tenant_id, array['owner', 'manager'])
    or core.is_platform_admin()
  );

drop policy if exists member_grants_write on core.member_grants;
create policy member_grants_write on core.member_grants
  for all using (core.has_tenant_role(tenant_id, array['owner', 'manager']) or core.is_platform_admin())
  with check (core.has_tenant_role(tenant_id, array['owner', 'manager']) or core.is_platform_admin());

drop policy if exists role_scopes_select on core.role_scopes;
create policy role_scopes_select on core.role_scopes for select using (true);

drop policy if exists tenant_modules_select on core.tenant_modules;
create policy tenant_modules_select on core.tenant_modules
  for select using (core.is_tenant_member(tenant_id) or core.is_platform_admin());
-- tenant_modules writes: service_role only (billing webhook / hub). No write policy = denied.

-- ----------------------------------------------------------------------------
-- Least-privilege grants (roles exist on Supabase; skipped on vanilla Postgres)
-- ----------------------------------------------------------------------------

revoke all on all functions in schema core from public;
revoke all on all tables in schema core from public;

do $$
declare
  r text;
begin
  foreach r in array array['authenticated', 'service_role'] loop
    if exists (select from pg_roles where rolname = r) then
      execute format('grant usage on schema core to %I', r);
      execute format('grant execute on all functions in schema core to %I', r);
      execute format('grant select on core.role_scopes to %I', r);
      execute format('grant select on core.tenant_modules to %I', r);
      execute format('grant select, insert, update, delete on core.member_grants to %I', r);
    end if;
  end loop;
  if exists (select from pg_roles where rolname = 'service_role') then
    grant insert, update, delete on core.tenant_modules to service_role;
  end if;
end;
$$;
