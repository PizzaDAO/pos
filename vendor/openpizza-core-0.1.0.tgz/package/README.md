# @openpizza/core

The Open Pizza module contract. Every module (guests, workforce, kitchen,
driver, kiosk, catering, sites, boards, pizza-mcp) depends **only** on this
package and on the hub's `/v1` URL, never on POS tables.

- `/v1` contract: zod schemas + inferred TS types
- `priceCart`: the one canonical server-side pricing function
- Event catalog (26 types), envelope, Standard Webhooks sign/verify, dedupe
- Roles → scopes, module ids, entitlements
- `CoreClient` with two implementations: HTTP (hub) and **MockCore**
  (in-memory, seeded, emits events, zero env)
- `PosAdapter` interface + a vitest conformance suite
- `openpizza-migrate`: per-schema migrations, plus core's `core.*` RLS helpers
- Money (integer cents, largest-remainder split), units (g/ml/each), hours
  (timezone-correct, multi-window, holidays)

Status: `0.1.0`, ESM only, Node ≥ 24. Pre-1.0: additive changes only in
minors; pin `~0.1`.

---

## Consuming it from a sibling module

Repos live side by side:

```
openpizza/
  core/            ← this repo (packages/core/dist is COMMITTED)
  guests/
  kitchen/
  …
```

In the module's `package.json`:

```json
"dependencies": {
  "@openpizza/core": "file:../core/packages/core",
  "zod": "^4.1.12"
}
```

and an `.npmrc` next to it (**recommended**):

```
install-links=true
```

With `install-links=true` npm installs a real copy of the package (plus its
`zod`/`pg` dependencies) into your `node_modules`. That works with Next.js /
Turbopack (no symlink outside the project root) and does **not** require
`npm install` inside `core/`. Because `dist/` is committed, no build step runs.

After pulling a newer core, refresh the copy (npm does not re-copy a
same-version folder dependency on its own):

```json
"scripts": { "core:refresh": "rm -rf node_modules/@openpizza/core && npm install" }
```

Without `install-links`, npm symlinks the folder instead. That gives live
updates but then `core/` must have been `npm install`ed (its `zod` resolves from
`core/node_modules`), and some bundlers dislike symlinks outside the root.

> Vercel/CI builds of a module only see that module's repo, so a `file:../core`
> dependency will not resolve there. Until `@openpizza/core` is published to
> npm (plans/core.md §11), deploy previews need a packed tarball or a git
> dependency. Local dev, tests and demos work as above.

Working on core itself: `npm install`, `npm run build` (rebuilds and must be
committed: `npm run check:dist` fails if `dist/` is stale), `npm test`,
`npm run typecheck`.

### Imports

```ts
import {
  createMockCore,
  priceCart,
  OrderSchema,
  type Order,
} from "@openpizza/core";
// or narrower, tree-shakeable subpaths:
import { MenuSchema } from "@openpizza/core/contract";
import { verifyWebhook } from "@openpizza/core/events";
import { allocate } from "@openpizza/core/money";
import { describePosAdapterConformance } from "@openpizza/core/conformance"; // needs vitest
import { migrate, checkSchemaScope } from "@openpizza/core/migrate"; // Node only
```

Subpaths: `contract`, `pricing`, `events`, `auth`, `money`, `units`, `hours`,
`client`, `mock`, `adapters`, `conformance`, `migrate`. The root re-exports all
but `conformance` and `migrate`. SQL ships at `@openpizza/core/migrations/*`
and `@openpizza/core/sql/*`.

---

## Zero-env development: MockCore

```ts
import {
  createHttpCoreClient,
  createMockCore,
  type CoreClient,
} from "@openpizza/core";

export const core: CoreClient = process.env.OPENPIZZA_CORE_URL
  ? createHttpCoreClient({
      baseUrl: process.env.OPENPIZZA_CORE_URL,
      token: getToken,
      module: "guests",
    })
  : createMockCore();
```

`createMockCore()` seeds **Tony's Pizza** (same ids as POS's seed):

- 2 locations: Downtown (delivery zones by postal code + radius, Sat open past
  midnight, split Sunday hours) and Uptown (lunch + dinner windows, closed
  Mondays, no delivery). Both have holiday hours. Tax 7%. Uptown has
  overrides: Large Margherita $19.49, anchovies 86'd. Downtown has zeppole 86'd.
- A full menu: 6 pizzas (S/M/L) with Crust/Sauce/Cheese/Toppings groups (roles,
  defaults, half-and-half, deep dish priced by size), knots, wings, Caesar,
  drinks, desserts, and a tax-exempt eGift card. US Big-9 allergens throughout.
- 11 staff across all 8 roles (one inactive), 8 customers with consent flags.
- 14 days of completed history (≈225 orders: in_store/online/kiosk/agent/phone,
  pickup/dine-in/delivery, half toppings, card + cash, cancellations), drawer
  sessions and closed business days. Plus live orders today in placed, preparing,
  ready, out_for_delivery and held (an unpaid agent order).
- A second tenant ("Slice of Life", Square-sourced) for isolation tests.
- Entitlements: every module enabled (kiosk on trial).

Well-known ids: `DEMO_TENANT_ID`, `DEMO_LOCATION_DOWNTOWN_ID`,
`DEMO_LOCATION_UPTOWN_ID`, `DEMO_IDS.items.pepperoni`, `DEMO_IDS.sizes.pepperoniL`,
`DEMO_IDS.modifiers.mushrooms`, `DEMO_IDS.staff.driver`, …

Options: `now` (a clock function for deterministic tests), `historyDays`
(default 14, 0 = none), `liveOrders` (default true), `seed` (PRNG, default 42),
`enforceHours` (default **true**; online/agent orders outside store hours fail
with `STORE_CLOSED`, so pass `false` for always-open demos), `historyEvents`
(default false: the pull feed starts empty), `tenantId`.

Beyond `CoreClient`:

```ts
const core = createMockCore({ now: () => clock });
core.subscribe((e) => console.log(e.type, e.sequence), { types: ["order.*"] });
core.addWebhookEndpoint({ url: "http://localhost:3001/api/core-webhooks", secret: "whsec_…" }); // real signed POSTs
await core.publish({ type: "guests.points_earned", source: "guests", subject: { type: "guest", id }, data });
await core.flush(); // await async handlers + webhook deliveries
core.asTenant(OTHER_TENANT_ID); // same store, other tenant

// What a POS / processor / driver would do:
await core.sim.pay(orderId);                 // captures balance due; releases awaiting_payment holds
await core.sim.advance(orderId);             // placed → accepted → preparing → ready → completed
await core.sim.refund(paymentId, 500);
await core.sim.expireHolds();
await core.sim.openDrawer(locId, staffId, 20_000); await core.sim.closeDrawer(id, counted);
await core.sim.closeBusinessDay(locId);      // emits business_day.closed
await core.sim.setModule("kiosk", { status: "disabled" }); // tenant.module.disabled + entitlements.changed
await core.sim.updateLocation(locId, { fulfillment: { …, accepting_orders: false } });
await core.sim.upsertStaff({ name: "New Cook", role: "kitchen" });
```

---

## Contract conventions

- **Tenancy comes from the token**, never a parameter. A `CoreClient` is bound
  to one tenant. Cross-tenant ids return `NOT_FOUND`.
- **Ids** are UUID strings (validated leniently with `z.guid()` so POS seed ids
  pass). Every resource has `external_ids: {source: id}`. Adapters mint stable
  ids with `externalUuid(tenant, source, type, externalId)` (UUIDv5).
- **Money** is integer minor units in `*_cents` fields; the currency lives on
  the resource (`order.currency`, `location.currency`). Never floats.
- **Timestamps** are RFC 3339 UTC. `business_date` is `YYYY-MM-DD` in the
  location timezone (`businessDate(at, tz)`).
- **Open enums** (`channel`, `payment method`, `modifier role`, `item kind`,
  `source kind` …) accept unknown lower_snake values at runtime. Always handle
  a default branch. Status enums (`fulfillment_status`, `payment_status`,
  tender and delivery status) are closed.
- **Pagination**: `{ data, next_cursor }`, pass `cursor` back. Use
  `paginate()` / `listAll()`.
- **Writes** are idempotent: pass `{ idempotencyKey }` (the HTTP client sends
  `Idempotency-Key`, generating one if omitted; `orders.create` uses the order's
  client `id`). Reusing a key with a different body → `IDEMPOTENCY_CONFLICT`.
  `ifMatch: version` → `CONFLICT` on mismatch.
- **Errors**: methods reject with `ProblemError` (`e.problem` is RFC 9457
  problem+json plus `code`, `retryable`, `path`, `details`, `suggestions`,
  `ask_user`, nested `errors`). Codes are stable UPPER_SNAKE (`ERROR_CODES`).
- **Capabilities**: check `core.capabilities.get()` / `supports(caps, flag)`
  before relying on writes or half placement (Square loses placement).

### Orders: two status axes

`fulfillment_status`: `held → placed → accepted → preparing → ready →
(out_for_delivery) → completed`, or `canceled`. `held` is hidden from kitchens
(unpaid agent orders, scheduled orders before `fire_at`) and `hold` says why
and when it expires. `payment_status`: `unpaid | partially_paid | paid |
partially_refunded | refunded`. POS's single `order_status` maps through
`fromPosOrderStatus()` (`in_kitchen`/`recall` → preparing, `paid` →
placed + paid, `voided` → canceled, `refunded` → payment axis).

`channel` (where it was taken: in_store, online, kiosk, agent, phone, catering,
marketplace) is separate from `fulfillment.type` (pickup, delivery, dine_in) and
from `source` (`type`, `module`, `agent_client_id`, `external_ref`,
`offline_synced`, `device_id`).

### Pricing: `priceCart`

Clients send ids, quantities and placements, **never prices**:

```ts
const quote = priceCart({
  menu,
  location,
  request: {
    location_id,
    lines: [
      {
        item_id,
        size_id,
        quantity: 1,
        modifiers: [{ modifier_id, placement: "left" }],
      },
    ],
    fulfillment: { type: "delivery", address, scheduled_for: null },
    adjustments: [
      {
        type: "loyalty_reward",
        source: "guests.reward",
        source_ref: holdId,
        label: "Free knots",
        amount_cents: 699,
        line_ids: ["l2"],
      },
    ],
    tip: { percent_bps: 1800 },
  },
});
if (!quote.valid) quote.errors; // every problem at once, each with a path
```

Rules (aligned with POS `pricing.ts`, `build-line.ts`, shop order route and
`scheduling.ts`): unit = size price + Σ modifiers; half placement =
`ceil(price/2)` (`half_price_ceil`); groups with `min_select` auto-apply their
`default_modifier_ids`; adjustments are pre-tax, clamped, and allocated to lines
by largest remainder (`line.discount_cents`, `line.net_cents`); tax =
`roundHalfUp(taxable × bps / 10 000)` once; delivery fee untaxed by default, tip
never taxed; tax-exempt lines (gift cards) and `tax_exempt` orders skip tax;
total = subtotal − discount + service fee + delivery fee + tax + tip. Fulfillment
gates: pickup/delivery/dine-in enabled, `accepting_orders`, delivery zone
(postal code, radius or polygon), zone minimum, ASAP open now and at now + prep,
scheduled ≥ prep + lead and ≤ horizon and open. `quote_hash` changes whenever a
price changes; ordering a stale quote → `PRICE_CHANGED` (with the new quote in
`details.quote`). `priceCartOrThrow` throws `QUOTE_INVALID` instead.

---

## Events and webhooks

Envelope: `{ id: "evt_<ULID>", type, spec_version: "1", data_version,
occurred_at, tenant_id, location_id, source, subject: {type, id, version},
sequence, data, changes }`. At-least-once (dedupe on `id`), no global order
(`subject.version` discards stale), `sequence` monotonic per tenant (gaps →
backfill via `events.list({ after })`).

Catalog (`EVENT_CATALOG`, each with a versioned zod payload): `order.placed`,
`order.updated`, `order.status_changed`, `order.ready`, `order.completed`,
`order.canceled`, `payment.authorized|captured|failed|refunded`,
`menu.updated`, `menu.item.unavailable|available`, `location.updated`,
`customer.created|updated`, `staff.created|updated|deactivated`,
`drawer_session.opened|closed`, `business_day.closed`,
`delivery.status_changed`, `tenant.module.enabled|disabled`,
`entitlements.changed`. Module events use their own namespace
(`guests.points_earned`); `shift.*` is reserved for workforce labor shifts.

Receiving (Standard Webhooks: `webhook-id`, `webhook-timestamp`,
`webhook-signature: v1,<base64>`; 5-minute tolerance; several secrets during
rotation):

```ts
import { verifyAndParseEvent, isEvent, dedupe } from "@openpizza/core";

export async function POST(req: Request) {
  const payload = await req.text(); // raw body, do not re-serialize
  const event = await verifyAndParseEvent({
    payload,
    headers: req.headers,
    secret: process.env.CORE_WEBHOOK_SECRET!,
  });
  await dedupe(inbox, event, async (e) => {
    if (isEvent(e, "order.completed")) await award(e.data);
  });
  return new Response(null, { status: 204 });
}
```

Sending: `signEvent(event, secret)` → `{ body, headers }`. Retry schedule:
`RETRY_SCHEDULE_SECONDS` / `retryDelaySeconds(attempt)`.

---

## Roles, scopes, modules

Scopes (`CORE_SCOPES`): `tenant:read`, `locations:read|write`,
`menu:read|write`, `menu.availability:write`, `orders:read|write`,
`quotes:write`, `payments:read|write`, `customers:read|write`,
`staff:read|write`, `drawer_sessions:read`, `deliveries:read|write`,
`sales:read`, `events:subscribe|publish`, `entitlements:read`, plus module
scopes (`guests:admin`, `kitchen:write`, `workforce:self`). Wildcards: `*`,
`orders:*`, `*:read`; `menu:write` implies `menu.availability:write`.

Roles (`ROLES`): POS roles `owner`, `manager`, `cashier`, `kitchen` plus new
`employee`, `driver`, `dispatcher`, `catering_manager`. The new ones live in
`core.member_grants`, not POS's enum, so they get **no POS back-office access**.
`ROLE_SCOPES` (TS) and `core.role_scopes` (SQL) are kept identical by a test.
Helpers: `hasScopes`, `missingScopes`, `scopesForRoles`, `requireScopes`.

Modules (`MODULE_IDS`): `pos`, `guests`, `workforce`, `kitchen`, `driver`,
`kiosk`, `catering`, `sites`, `boards`, `pizza_mcp`; `MODULE_SCHEMAS` maps each
to its Postgres schema. `isModuleEnabled(entitlements, "guests")` fails closed;
`moduleLimit(ent, "boards", "max_screens", 1)`.

---

## Database: one schema per module

Rules: a module runs DDL only in its own schema, never reads another module's
tables (POS `public` included), stores `tenant_id` (and `location_id`) without
foreign keys, and FORCEs RLS with policies that call only `core.*` helpers.

### Core helpers (apply once per project)

```bash
npx openpizza-migrate up --core --url "$DATABASE_URL"
```

creates schema `core` with SECURITY DEFINER helpers (shared mode, wrapping POS's
`public.memberships` / `platform_admins` + `core.member_grants`):

| Function                                          | Meaning                                                   |
| ------------------------------------------------- | --------------------------------------------------------- |
| `core.is_tenant_member(tenant uuid)`              | POS member, core grant, or a machine claim `tid = tenant` |
| `core.has_tenant_role(tenant uuid, roles text[])` | user holds any of the roles                               |
| `core.has_scope(tenant uuid, scope text)`         | via role scopes or the claim's `scope`                    |
| `core.is_platform_admin()`                        | POS platform admin                                        |
| `core.current_tenant_ids()`                       | all tenants the caller can see                            |
| `core.module_enabled(tenant uuid, module text)`   | `core.tenant_modules` enabled/trial                       |
| `core.current_user_id()`                          | `auth.uid()`                                              |

Module server code connecting as its own role sets claims per transaction:
`select set_config('request.jwt.claims', '{"tid":"…","scope":"guests:write"}', true)`.
For a standalone module database, apply `sql/standalone/core_helpers_jwt.sql`
instead: same names, answers purely from JWT claims, so policies are portable.
`sql/provision_module_role.sql` creates a module's login role and schema.

```sql
create table guests.profiles (id uuid primary key, tenant_id uuid not null, …);
alter table guests.profiles enable row level security;
alter table guests.profiles force row level security;
create policy profiles_rw on guests.profiles
  using (core.is_tenant_member(tenant_id)) with check (core.has_scope(tenant_id, 'guests:write'));
```

### Your module's migrations

```bash
npx openpizza-migrate check  --schema guests --dir db/migrations            # CI lint, no DB
npx openpizza-migrate up     --schema guests --dir db/migrations --dry-run
npx openpizza-migrate up     --schema guests --dir db/migrations            # uses $DATABASE_URL
npx openpizza-migrate status --schema guests --dir db/migrations
```

Files are `NNNN_name.sql`, applied in numeric order, each in its own
transaction with `search_path = <schema>, extensions`, under
`pg_advisory_lock`, tracked in `<schema>.schema_migrations` (version, name,
sha256 checksum). Editing an applied file is refused (add a new migration).
Statements that target another schema (`alter table public.orders …`,
`grant … on schema public`, `insert into core.…`), `CREATE EXTENSION`, roles,
`SET ROLE` and `SET search_path` are refused unless explicitly allowed
(`--allow-schema`, `--allow-extensions`, `--allow-roles`). `--role mod_guests`
runs each file as the module's owner role. Programmatic API: `migrate({ db,
schema, files })`, `loadMigrationFiles(dir)`, `checkSchemaScope(sql, schema)`,
`connectPg(url)`.

---

## Adapters and conformance

`PosAdapter` (alias `CommerceAdapter`) maps a commerce source (POS, Square,
Clover, Toast) onto the contract. Optional methods are optional capabilities
and must match `capabilities()`. Register with `createAdapterRegistry()`.

```ts
// square.conformance.test.ts
import { describePosAdapterConformance } from "@openpizza/core/conformance";
describePosAdapterConformance({
  name: "square sandbox",
  adapter: () => createSquareAdapter(),
  context: () => ({ tenant_id, connection }),
  allowWrites: false, // true also exercises create/cancel idempotency
  sampleWebhook: () => loadSignedFixture(),
});
```

It checks capabilities against implemented methods, schema validity of
locations/menu/orders/customers/staff, tenant scoping, pagination, totals
invariants (`orderViolations`), `NOT_FOUND` problems, server-side quotes,
webhook normalization and backfill. `createMockPosAdapter(mockCore)` is the
reference implementation and passes it.

---

## API index

- **contract**: `TenantSchema`, `LocationSchema` (+ `HoursSchema`,
  `DayHoursSchema`, `SpecialHoursSchema`, `JurisdictionSchema`,
  `DeliveryZoneSchema`, `FulfillmentSettingsSchema`, `PricingSettingsSchema`),
  `MenuSchema` (+ `MenuCategorySchema`, `MenuItemSchema`, `ItemSizeSchema`,
  `ModifierGroupSchema`, `ModifierSchema`, `AvailabilitySchema`,
  `AllergenInfoSchema`, `US_ALLERGENS`, `EU_ALLERGENS`, `PLACEMENTS`,
  `MODIFIER_ROLES`, `HALF_PRICING_RULES`), cart inputs (`CartLineInputSchema`,
  `AdjustmentInputSchema`, `FulfillmentRequestSchema`, `TipInputSchema`),
  `OrderSchema` (+ `OrderLineSchema`, `AdjustmentSchema`, `OrderTotalsSchema`,
  `TenderSchema`, `HoldSchema`, `OrderCreateInputSchema`,
  `OrderCancelInputSchema`, `OrderListQuerySchema`, `FULFILLMENT_STATUSES`,
  `PAYMENT_STATUSES`, `canTransition`, `fromPosOrderStatus`, `fromPosChannel`),
  `QuoteRequestSchema`, `QuoteSchema`, `PaymentSchema`,
  `ExternalTenderInputSchema`, `CustomerSchema`, `CustomerUpsertInputSchema`,
  `StaffMemberSchema`, `DrawerSessionSchema`, `DeliverySchema`,
  `DailySalesSchema`, `SalesSummarySchema`, `CapabilitiesSchema`,
  `EntitlementsSchema`, `ModuleManifestSchema`, `ProblemSchema`, `problem()`,
  `ProblemError`, `ERROR_CODES`, `openEnum()`, `pageOf()`.
- **pricing**: `priceCart`, `priceCartOrThrow`, `placementPriceCents`,
  `matchDeliveryZone`, `totalsViolations`, `orderViolations`.
- **events**: `EVENT_CATALOG`, `EVENT_TYPES`, `createEvent`, `parseEvent`,
  `isEvent`, `matchesEventType`, `signWebhook`, `webhookHeaders`, `signEvent`,
  `verifyWebhook`, `verifyAndParseEvent`, `generateWebhookSecret`,
  `createMemoryInbox`, `dedupe`, `retryDelaySeconds`.
- **auth**: `ROLES`, `ROLE_SCOPES`, `CORE_SCOPES`, `hasScopes`,
  `missingScopes`, `scopesForRoles`, `requireScopes`, `requireLocation`,
  `CoreTokenClaimsSchema`, `principalFromClaims`, `MODULE_IDS`,
  `MODULE_SCHEMAS`, `isModuleEnabled`, `moduleLimit`.
- **money**: `allocate`, `splitEvenly`, `applyBps`, `roundHalfUp`,
  `formatMoney`, `toMinorUnits`, `fromMinorUnits`, `currencyExponent`.
- **units**: `UNITS`, `UnitSchema`, `convert`, `toBase`, `dimensionOf`,
  `roundQty`.
- **hours**: `isOpenAt`, `nextOpenAt`, `currentWindow`, `isOpenThrough`,
  `hoursForService`, `businessDate`, `localParts`, `zonedTimeToUtc`.
- **ids**: `uuidv5`, `externalUuid`, `ulid`, `randomId`, `stableHash`.
- **client**: `CoreClient`, `createHttpCoreClient`, `V1_ROUTES`, `paginate`,
  `listAll`.
- **mock**: `createMockCore`, `createMockPosAdapter`, `DEMO_*` ids.
- **adapters**: `PosAdapter`, `AdapterContext`, `createAdapterRegistry`.
- **conformance**: `describePosAdapterConformance`.
- **migrate**: `migrate`, `planMigrations`, `checkSchemaScope`,
  `loadMigrationFiles`, `coreMigrationsDir`, `connectPg`, `runCli`.
