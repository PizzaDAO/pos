# @openpizza/core

The Open Pizza module contract. Every module (guests, workforce, kitchen,
driver, kiosk, catering, sites, boards, pizza-mcp) depends **only** on this
package and on the hub's `/v1` URL, never on POS tables.

- `/v1` contract: zod schemas + inferred TS types
- `priceCart`: the one canonical server-side pricing function
- Event catalog (26 types), envelope, Standard Webhooks sign/verify, dedupe
- Roles → scopes, module ids, entitlements
- `CoreClient` with two implementations: HTTP (hub) and **MockCore**
  (in-memory, seeded, emits events, zero env)
- `PosAdapter` interface + a vitest conformance suite
- `openpizza-migrate`: per-schema migrations, plus core's `core.*` RLS helpers
- Money (integer cents, largest-remainder split), units (g/ml/each), hours
  (timezone-correct, multi-window, holidays)

Status: `0.3.0`, ESM only, Node ≥ 24. Pre-1.0: additive changes only in
minors; pin `~0.3` (0.1 / 0.2 code keeps working unchanged).

**New in 0.3.0 (additive; closes the module gaps, see `../../docs/GAPS.md`):**
`backofhouse` module id (`kitchen` = deprecated alias) and per-module scope
families; `events.publish` with namespace rules (`canPublishEvent`); tenant
directory + geo search; module settings; device pairing/principals; staff-PIN
sessions; shared customer OTP; realtime nudges; notifications; checkout and
delivery provider protocols + registry; payment sessions + payments account +
`recordExternal` pending/COD/invoice semantics; fee/gratuity lines; order
`status_history`/`status_at_void`/`callout_name`; hourly/item sales, tips,
kitchen load, allergen publication; 12 new catalog events; dayparts; literal
scopes (`orders:discount`, `orders:place_direct`, `orders:release_unpaid`) that
no wildcard covers. POS serves `V1_ROUTES` under `POS_API_BASE_PATH` (`/api/v1`).

**New in 0.2.0 (additive):** core token helpers on `jose`
(`createCoreTokenVerifier`, `signCoreToken`, `bearerToken`,
`createClientCredentialsTokenSource`, `generateSigningKey`, `toJwks`),
`HUB_ROUTES` (event ingest, webhook endpoints, replay, delivery log), and
optional `PosAdapter` methods covering the rest of `/v1`. The hub that issues
the tokens and serves the API lives in `apps/hub`.

---

## Consuming it from a sibling module

Repos live side by side:

```
openpizza/
  core/            ← this repo (packages/core/dist is COMMITTED)
  guests/
  kitchen/
  …
```

In the module's `package.json`:

```json
"dependencies": {
  "@openpizza/core": "file:../core/packages/core",
  "zod": "^4.1.12"
}
```

and an `.npmrc` next to it (**recommended**):

```
install-links=true
```

With `install-links=true` npm installs a real copy of the package (plus its
`zod`/`pg` dependencies) into your `node_modules`. That works with Next.js /
Turbopack (no symlink outside the project root) and does **not** require
`npm install` inside `core/`. Because `dist/` is committed, no build step runs.

After pulling a newer core, refresh the copy (npm does not re-copy a
same-version folder dependency on its own):

```json
"scripts": { "core:refresh": "rm -rf node_modules/@openpizza/core && npm install" }
```

Without `install-links`, npm symlinks the folder instead. That gives live
updates but then `core/` must have been `npm install`ed (its `zod` resolves from
`core/node_modules`), and some bundlers dislike symlinks outside the root.

> Vercel/CI builds of a module only see that module's repo, so a `file:../core`
> dependency will not resolve there. Until `@openpizza/core` is published to
> npm (plans/core.md §11), deploy previews need a packed tarball or a git
> dependency. Local dev, tests and demos work as above.

Working on core itself: `npm install`, `npm run build` (rebuilds and must be
committed: `npm run check:dist` fails if `dist/` is stale), `npm test`,
`npm run typecheck`.

### Imports

```ts
import {
  createMockCore,
  priceCart,
  OrderSchema,
  type Order,
} from "@openpizza/core";
// or narrower, tree-shakeable subpaths:
import { MenuSchema } from "@openpizza/core/contract";
import { verifyWebhook } from "@openpizza/core/events";
import { allocate } from "@openpizza/core/money";
import { describePosAdapterConformance } from "@openpizza/core/conformance"; // needs vitest
import { migrate, checkSchemaScope } from "@openpizza/core/migrate"; // Node only
```

Subpaths: `contract`, `pricing`, `events`, `auth`, `money`, `units`, `hours`,
`client`, `mock`, `adapters`, `conformance`, `migrate`. The root re-exports all
but `conformance` and `migrate`. SQL ships at `@openpizza/core/migrations/*`
and `@openpizza/core/sql/*`.

---

## Zero-env development: MockCore

```ts
import {
  createHttpCoreClient,
  createMockCore,
  type CoreClient,
} from "@openpizza/core";

export const core: CoreClient = process.env.OPENPIZZA_CORE_URL
  ? createHttpCoreClient({
      baseUrl: process.env.OPENPIZZA_CORE_URL,
      token: getToken,
      module: "guests",
    })
  : createMockCore();
```

`createMockCore()` seeds **Tony's Pizza** (same ids as POS's seed):

- 2 locations: Downtown (delivery zones by postal code + radius, Sat open past
  midnight, split Sunday hours) and Uptown (lunch + dinner windows, closed
  Mondays, no delivery). Both have holiday hours. Tax 7%. Uptown has
  overrides: Large Margherita $19.49, anchovies 86'd. Downtown has zeppole 86'd.
- A full menu: 6 pizzas (S/M/L) with Crust/Sauce/Cheese/Toppings groups (roles,
  defaults, half-and-half, deep dish priced by size), knots, wings, Caesar,
  drinks, desserts, and a tax-exempt eGift card. US Big-9 allergens throughout.
- 11 staff across all 8 roles (one inactive), 8 customers with consent flags.
- 14 days of completed history (≈225 orders: in_store/online/kiosk/agent/phone,
  pickup/dine-in/delivery, half toppings, card + cash, cancellations), drawer
  sessions and closed business days. Plus live orders today in placed, preparing,
  ready, out_for_delivery and held (an unpaid agent order).
- A second tenant ("Slice of Life", Square-sourced) for isolation tests.
- Entitlements: every module enabled (kiosk on trial).

Well-known ids: `DEMO_TENANT_ID`, `DEMO_LOCATION_DOWNTOWN_ID`,
`DEMO_LOCATION_UPTOWN_ID`, `DEMO_IDS.items.pepperoni`, `DEMO_IDS.sizes.pepperoniL`,
`DEMO_IDS.modifiers.mushrooms`, `DEMO_IDS.staff.driver`, …

Options: `now` (a clock function for deterministic tests), `historyDays`
(default 14, 0 = none), `liveOrders` (default true), `seed` (PRNG, default 42),
`enforceHours` (default **true**; online/agent orders outside store hours fail
with `STORE_CLOSED`, so pass `false` for always-open demos), `historyEvents`
(default false: the pull feed starts empty), `tenantId`.

Beyond `CoreClient`:

```ts
const core = createMockCore({ now: () => clock });
core.subscribe((e) => console.log(e.type, e.sequence), { types: ["order.*"] });
core.addWebhookEndpoint({ url: "http://localhost:3001/api/core-webhooks", secret: "whsec_…" }); // real signed POSTs
await core.publish({ type: "guests.points_earned", source: "guests", subject: { type: "guest", id }, data });
await core.flush(); // await async handlers + webhook deliveries
core.asTenant(OTHER_TENANT_ID); // same store, other tenant

// What a POS / processor / driver would do:
await core.sim.pay(orderId);                 // captures balance due; releases awaiting_payment holds
await core.sim.advance(orderId);             // placed → accepted → preparing → ready → completed
await core.sim.refund(paymentId, 500);
await core.sim.expireHolds();
await core.sim.openDrawer(locId, staffId, 20_000); await core.sim.closeDrawer(id, counted);
await core.sim.closeBusinessDay(locId);      // emits business_day.closed
await core.sim.setModule("kiosk", { status: "disabled" }); // tenant.module.disabled + entitlements.changed
await core.sim.updateLocation(locId, { fulfillment: { …, accepting_orders: false } });
await core.sim.upsertStaff({ name: "New Cook", role: "kitchen" });
```

---

## Contract conventions

- **Tenancy comes from the token**, never a parameter. A `CoreClient` is bound
  to one tenant. Cross-tenant ids return `NOT_FOUND`.
- **Ids** are UUID strings (validated leniently with `z.guid()` so POS seed ids
  pass). Every resource has `external_ids: {source: id}`. Adapters mint stable
  ids with `externalUuid(tenant, source, type, externalId)` (UUIDv5).
- **Money** is integer minor units in `*_cents` fields; the currency lives on
  the resource (`order.currency`, `location.currency`). Never floats.
- **Timestamps** are RFC 3339 UTC. `business_date` is `YYYY-MM-DD` in the
  location timezone (`businessDate(at, tz)`).
- **Open enums** (`channel`, `payment method`, `modifier role`, `item kind`,
  `source kind` …) accept unknown lower_snake values at runtime. Always handle
  a default branch. Status enums (`fulfillment_status`, `payment_status`,
  tender and delivery status) are closed.
- **Pagination**: `{ data, next_cursor }`, pass `cursor` back. Use
  `paginate()` / `listAll()`.
- **Writes** are idempotent: pass `{ idempotencyKey }` (the HTTP client sends
  `Idempotency-Key`, generating one if omitted; `orders.create` uses the order's
  client `id`). Reusing a key with a different body → `IDEMPOTENCY_CONFLICT`.
  `ifMatch: version` → `CONFLICT` on mismatch.
- **Errors**: methods reject with `ProblemError` (`e.problem` is RFC 9457
  problem+json plus `code`, `retryable`, `path`, `details`, `suggestions`,
  `ask_user`, nested `errors`). Codes are stable UPPER_SNAKE (`ERROR_CODES`).
- **Capabilities**: check `core.capabilities.get()` / `supports(caps, flag)`
  before relying on writes or half placement (Square loses placement).

### Orders: two status axes

`fulfillment_status`: `held → placed → accepted → preparing → ready →
(out_for_delivery) → completed`, or `canceled`. `held` is hidden from kitchens
(unpaid agent orders, scheduled orders before `fire_at`) and `hold` says why
and when it expires. `payment_status`: `unpaid | partially_paid | paid |
partially_refunded | refunded`. POS's single `order_status` maps through
`fromPosOrderStatus()` (`in_kitchen`/`recall` → preparing, `paid` →
placed + paid, `voided` → canceled, `refunded` → payment axis).

`channel` (where it was taken: in_store, online, kiosk, agent, phone, catering,
marketplace) is separate from `fulfillment.type` (pickup, delivery, dine_in) and
from `source` (`type`, `module`, `agent_client_id`, `external_ref`,
`offline_synced`, `device_id`).

### Pricing: `priceCart`

Clients send ids, quantities and placements, **never prices**:

```ts
const quote = priceCart({
  menu,
  location,
  request: {
    location_id,
    lines: [
      {
        item_id,
        size_id,
        quantity: 1,
        modifiers: [{ modifier_id, placement: "left" }],
      },
    ],
    fulfillment: { type: "delivery", address, scheduled_for: null },
    adjustments: [
      {
        type: "loyalty_reward",
        source: "guests.reward",
        source_ref: holdId,
        label: "Free knots",
        amount_cents: 699,
        line_ids: ["l2"],
      },
    ],
    tip: { percent_bps: 1800 },
  },
});
if (!quote.valid) quote.errors; // every problem at once, each with a path
```

Rules (aligned with POS `pricing.ts`, `build-line.ts`, shop order route and
`scheduling.ts`): unit = size price + Σ modifiers; half placement =
`ceil(price/2)` (`half_price_ceil`); groups with `min_select` auto-apply their
`default_modifier_ids`; adjustments are pre-tax, clamped, and allocated to lines
by largest remainder (`line.discount_cents`, `line.net_cents`); tax =
`roundHalfUp(taxable × bps / 10 000)` once; delivery fee untaxed by default, tip
never taxed; tax-exempt lines (gift cards) and `tax_exempt` orders skip tax;
total = subtotal − discount + service fee + delivery fee + tax + tip. Fulfillment
gates: pickup/delivery/dine-in enabled, `accepting_orders`, delivery zone
(postal code, radius or polygon), zone minimum, ASAP open now and at now + prep,
scheduled ≥ prep + lead and ≤ horizon and open. `quote_hash` changes whenever a
price changes; ordering a stale quote → `PRICE_CHANGED` (with the new quote in
`details.quote`). `priceCartOrThrow` throws `QUOTE_INVALID` instead.

---

## Events and webhooks

Envelope: `{ id: "evt_<ULID>", type, spec_version: "1", data_version,
occurred_at, tenant_id, location_id, source, subject: {type, id, version},
sequence, data, changes }`. At-least-once (dedupe on `id`), no global order
(`subject.version` discards stale), `sequence` monotonic per tenant (gaps →
backfill via `events.list({ after })`).

Catalog (`EVENT_CATALOG`, each with a versioned zod payload): `order.placed`,
`order.updated`, `order.status_changed`, `order.ready`, `order.completed`,
`order.canceled`, `payment.authorized|captured|failed|refunded`,
`menu.updated`, `menu.item.unavailable|available`, `location.updated`,
`customer.created|updated`, `staff.created|updated|deactivated`,
`drawer_session.opened|closed`, `business_day.closed`,
`delivery.status_changed`, `tenant.module.enabled|disabled`,
`entitlements.changed`. Module events use their own namespace
(`guests.points_earned`); `shift.*` is reserved for workforce labor shifts.

Receiving (Standard Webhooks: `webhook-id`, `webhook-timestamp`,
`webhook-signature: v1,<base64>`; 5-minute tolerance; several secrets during
rotation):

```ts
import { verifyAndParseEvent, isEvent, dedupe } from "@openpizza/core";

export async function POST(req: Request) {
  const payload = await req.text(); // raw body, do not re-serialize
  const event = await verifyAndParseEvent({
    payload,
    headers: req.headers,
    secret: process.env.CORE_WEBHOOK_SECRET!,
  });
  await dedupe(inbox, event, async (e) => {
    if (isEvent(e, "order.completed")) await award(e.data);
  });
  return new Response(null, { status: 204 });
}
```

Sending: `signEvent(event, secret)` → `{ body, headers }`. Retry schedule:
`RETRY_SCHEDULE_SECONDS` / `retryDelaySeconds(attempt)`.

### One receiver, many tenants: bind secrets to tenants (0.3.1)

Every tenant's hub endpoint has its own secret, and whoever created the
endpoint knows it. If one receiver verifies against "any configured secret",
tenant A can sign an event that names tenant B. Bind each secret to its
tenant (and endpoint) instead; the hub signs `tenant_id` and `endpoint_id`
into every delivery body:

```ts
const event = await verifyAndParseEvent({
  payload,
  headers: req.headers,
  // from your own table: one row per hub endpoint you created
  endpoints: rows.map((r) => ({
    secret: r.secrets, // current (+ previous during rotation)
    tenant_id: r.tenant_id,
    endpoint_id: r.endpoint_id,
  })),
  // or: secretsByTenant: { [tenantId]: secret }
});
// WebhookVerificationError reason "tenant_mismatch" → 401, do not process
```

Recommended: the module creates its endpoints itself, per tenant, with its
own module client token (`POST /v1/webhook-endpoints`, scope `events:subscribe`), so the secret goes
only to the module (it is never readable through PostgREST and is not shown
to tenant staff). Store it keyed by tenant; see `docs/DEPLOY.md`.

---

## Machine tokens (0.2.0)

The hub issues ES256 JWTs from `POST /oauth/token` (client_credentials, 5–15
min). Calling the hub from a module:

```ts
import {
  createClientCredentialsTokenSource,
  createHttpCoreClient,
} from "@openpizza/core";

const token = createClientCredentialsTokenSource({
  tokenUrl: `${process.env.OPENPIZZA_HUB_URL}/oauth/token`,
  clientId: process.env.OPENPIZZA_CLIENT_ID!,
  clientSecret: process.env.OPENPIZZA_CLIENT_SECRET!,
  tenantId, // first-party module clients name the tenant per token
}); // cached; refreshes 60 s before expiry
const core = createHttpCoreClient({
  baseUrl: `${process.env.OPENPIZZA_HUB_URL}/v1`,
  token,
  module: "guests",
});
```

Verifying tokens the hub (or another module) sends you:

```ts
import {
  bearerToken,
  createCoreTokenVerifier,
  requireScopes,
} from "@openpizza/core";

const verify = createCoreTokenVerifier({
  jwks: `${process.env.OPENPIZZA_HUB_URL}/.well-known/jwks.json`, // fetched + cached
  issuer: process.env.OPENPIZZA_HUB_ISSUER,
});
const { claims, principal } = await verify(bearerToken(req.headers)); // ProblemError UNAUTHENTICATED on failure
requireScopes(principal, ["guests:admin"]); // tenant = principal.tenant_id, never a param
```

Tests can mint tokens locally: `const key = await generateSigningKey()`,
`signCoreToken({ key, issuer, sub, tid, scope })`, and verify with
`createCoreTokenVerifier({ jwks: toJwks([key]) })`.

### Error contract: fail closed correctly (0.3.1)

Every package HTTP helper (`createClientCredentialsTokenSource`,
`createCoreTokenVerifier`, `createHttpCoreClient`, `pairDevice`, remote
providers, `createHubLogin`) rejects with a `ProblemError` from one table.
Match on `code` / `status`, never on message text:

| Situation                                                  | `code`                 | status | retryable | What the module does                                 |
| ---------------------------------------------------------- | ---------------------- | ------ | --------- | ---------------------------------------------------- |
| hub `400 unauthorized_client` (module disabled for tenant) | `MODULE_DISABLED`      | 403    | no        | deny; show "not enabled"; do not retry               |
| hub `401 invalid_client` (bad id/secret, revoked)          | `INVALID_CLIENT`       | 401    | no        | deny; alert ops (config)                             |
| bad/expired token, grant, or pairing code                  | `UNAUTHENTICATED`      | 401    | no        | deny; re-authenticate                                |
| unknown resource / pairing code                            | `NOT_FOUND`            | 404    | no        |                                                      |
| 429, 5xx, network error, timeout, non-JSON error page      | `UPSTREAM_UNAVAILABLE` | 503    | yes       | deny (fail closed) and answer 503 with `Retry-After` |
| JWKS unreachable and no keys cached                        | `UPSTREAM_UNAVAILABLE` | 503    | yes       | same; never treat as "bad token"                     |

`retryAfterSeconds(e)` gives `details.retry_after_seconds` (from the hub's
`Retry-After`, default 5). The token source keeps returning a still-valid
cached token while the hub is down; the verifier keeps verifying with its
last good JWKS (refetched every 10 min, or on an unknown `kid` at most every
30 s). Helpers: `problemFromResponse(res, body, what)`, `tokenError`,
`parseRetryAfter`, `hubUnavailable`.

```ts
try {
  principal = (await verify(bearerToken(req.headers))).principal;
} catch (e) {
  if (!isProblemError(e)) throw e;
  const after = retryAfterSeconds(e);
  return Response.json(e.problem, {
    status: e.status, // 401 / 403 / 503
    headers: after ? { "retry-after": String(after) } : {},
  });
}
```

### Staff sign-in through the hub (0.3.1, GAPS #44 minimal)

Replace "paste a token" pages with `createHubLogin`. Register the exact
callback URL on the module's hub client (console → Clients → "Staff-login
redirect URIs").

```ts
import { createHubLogin } from "@openpizza/core";

const login = createHubLogin({
  hubUrl: process.env.OPENPIZZA_HUB_URL!,
  clientId: process.env.OPENPIZZA_CLIENT_ID!,
  clientSecret: process.env.OPENPIZZA_CLIENT_SECRET!,
  redirectUri: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback`,
});
// GET /login
const { url, state, codeVerifier } = await login.start(); // { tenantId? }
// set httpOnly cookie {state, codeVerifier} (10 min), redirect to url
// GET /auth/callback?code&state (or ?error=access_denied)
const s = await login.finish({
  code,
  state,
  expectedState,
  codeVerifier,
  error,
});
// s.access_token: 15 min staff token, aud "openpizza:staff:<client_id>", s.staff, s.tenant_id
const { principal } = await login.verify(s.access_token); // only tokens for THIS client; kind "user", roles, scopes
```

The staff token is for the module (its pages, API, RLS claims: `tid`,
`scope`, `op_roles`, `op_modules`); core's `/v1` and other modules reject
it. Its scopes are the member's role scopes narrowed to the module's own
scope family plus `tenant:read locations:read` (never `*` or literal
scopes). Only first-party module clients can use the staff login, and the
first sign-in per client shows a consent screen. Call core with
the module client token. The hub keeps an 8 h sign-in session, so after the
token expires `login.start()` again redirects straight back.

## Roles, scopes, modules

Scopes (`CORE_SCOPES`): `tenant:read`, `locations:read|write`,
`menu:read|write`, `menu.availability:write`, `orders:read|write`,
`quotes:write`, `payments:read|write`, `customers:read|write`,
`staff:read|write`, `drawer_sessions:read`, `deliveries:read|write`,
`sales:read`, `events:subscribe|publish`, `entitlements:read`, plus module
scopes (`guests:admin`, `kitchen:write`, `workforce:self`). Wildcards: `*`,
`orders:*`, `*:read`; `menu:write` implies `menu.availability:write`.

Roles (`ROLES`): POS roles `owner`, `manager`, `cashier`, `kitchen` plus new
`employee`, `driver`, `dispatcher`, `catering_manager`. The new ones live in
`core.member_grants`, not POS's enum, so they get **no POS back-office access**.
`ROLE_SCOPES` (TS) and `core.role_scopes` (SQL) are kept identical by a test.
Helpers: `hasScopes`, `missingScopes`, `scopesForRoles`, `requireScopes`.

Modules (`MODULE_IDS`): `pos`, `guests`, `workforce`, `kitchen`, `driver`,
`kiosk`, `catering`, `sites`, `boards`, `pizza_mcp`; `MODULE_SCHEMAS` maps each
to its Postgres schema. `isModuleEnabled(entitlements, "guests")` fails closed;
`moduleLimit(ent, "boards", "max_screens", 1)`.

---

## Database: one schema per module

Rules: a module runs DDL only in its own schema, never reads another module's
tables (POS `public` included), stores `tenant_id` (and `location_id`) without
foreign keys, and FORCEs RLS with policies that call only `core.*` helpers.

### Core helpers (apply once per project)

```bash
npx openpizza-migrate up --core --url "$DATABASE_URL"
```

creates schema `core` with SECURITY DEFINER helpers (shared mode, wrapping POS's
`public.memberships` / `platform_admins` + `core.member_grants`):

| Function                                          | Meaning                                                   |
| ------------------------------------------------- | --------------------------------------------------------- |
| `core.is_tenant_member(tenant uuid)`              | POS member, core grant, or a machine claim `tid = tenant` |
| `core.has_tenant_role(tenant uuid, roles text[])` | user holds any of the roles                               |
| `core.has_scope(tenant uuid, scope text)`         | via role scopes or the claim's `scope`                    |
| `core.is_platform_admin()`                        | POS platform admin                                        |
| `core.current_tenant_ids()`                       | all tenants the caller can see                            |
| `core.module_enabled(tenant uuid, module text)`   | `core.tenant_modules` enabled/trial                       |
| `core.current_user_id()`                          | `auth.uid()`                                              |

0.3.1 adds once-per-statement helpers (core migration 0004):

| Function                                  | Meaning                                                     |
| ----------------------------------------- | ----------------------------------------------------------- |
| `core.claim_tenant_id()`                  | the token's `tid` (plain SQL, inlinable)                    |
| `core.has_scope(scope text)`              | the token's own scopes cover `scope` (claim tenant, no row) |
| `core.tenant_ids_with_role(roles text[])` | tenants where the caller holds one of the roles             |
| `core.tenant_ids_with_scope(scope text)`  | tenants where the caller has the scope (claim or role)      |

Module server code connecting as its own role sets claims per transaction:
`select set_config('request.jwt.claims', '{"tid":"…","scope":"guests:write"}', true)`.
`sql/provision_module_role.sql` (or `provisionModuleRoleSql({ module,
password })` from `@openpizza/core/migrate`) creates `<module>_owner`
(NOLOGIN, owns the schema; run migrations with `--role <module>_owner`) and
`mod_<module>` (the app's login role: DML only, cannot alter/drop tables or
disable RLS).

### RLS policy pattern for modules (0.3.1)

`core.is_tenant_member(tenant_id)` and `core.has_scope(tenant_id, …)` are
SECURITY DEFINER and take a per-row argument, so Postgres runs them once
**per row** (measured ~30 µs / ~250 µs per row: a 21k-row table took 5 s).
A `for all` policy is OR'ed into every SELECT, so write checks slow reads too.
Compare the row's tenant with values computed **once per statement**:

```sql
alter table guests.profiles enable row level security;
alter table guests.profiles force row level security;

create policy profiles_select on guests.profiles for select using (
  tenant_id = (select core.claim_tenant_id())        -- module/JWT callers (initplan)
  or tenant_id in (select core.current_tenant_ids()) -- signed-in members (hashed subplan)
);
create policy profiles_insert on guests.profiles for insert with check (
  tenant_id = (select core.claim_tenant_id()) and (select core.has_scope('guests:write'))
);
create policy profiles_update on guests.profiles for update
  using (tenant_id = (select core.claim_tenant_id()) and (select core.has_scope('guests:write')))
  with check (tenant_id = (select core.claim_tenant_id()));
create policy profiles_delete on guests.profiles for delete using (
  tenant_id = (select core.claim_tenant_id()) and (select core.has_scope('guests:admin'))
);
-- role-gated: tenant_id in (select core.tenant_ids_with_role(array['owner','manager']))
```

Rules: wrap every helper in `(select …)`; never pass a row column to a
SECURITY DEFINER helper in a hot policy; separate insert/update/delete
policies (no `for all`); index `tenant_id`. The package test runs 50k rows
under this pattern on Postgres 16 in well under 100 ms.

### Plain Postgres: `--standalone` and test bootstrap (0.3.1)

```bash
npx openpizza-migrate up --core --standalone --url "$DATABASE_URL"
```

On a plain Postgres (a module's own database, CI, `test:pg`), this applies
`sql/standalone/test-bootstrap.sql` (roles `anon`/`authenticated`/
`service_role`, `auth.uid()` from the `sub` claim, stub
`public.memberships`/`platform_admins`), then core's migrations, then
`sql/standalone/core_helpers_jwt.sql` (same helper names, answers purely from
JWT claims: `tid`, `scope`, `op_roles`, `op_modules`). It refuses a database
with real POS tables. Run it as a superuser.

For module tests that want shared-mode semantics (insert a membership, check
RLS), apply only the bootstrap, then shared `up --core`:

```ts
import { standaloneBootstrapSql } from "@openpizza/core/migrate";
await db.exec(standaloneBootstrapSql()); // = @openpizza/core/sql/standalone/test-bootstrap.sql
await runCli(["up", "--core", "--url", url]);
```

This replaces each module's hand-rolled `pg-bootstrap.sql` / tenancy stub.

### Your module's migrations

```bash
npx openpizza-migrate check  --schema guests --dir db/migrations            # CI lint, no DB
npx openpizza-migrate up     --schema guests --dir db/migrations --dry-run
npx openpizza-migrate up     --schema guests --dir db/migrations            # uses $DATABASE_URL
npx openpizza-migrate status --schema guests --dir db/migrations
```

Files are `NNNN_name.sql`, applied in numeric order, each in its own
transaction with `search_path = <schema>, extensions`, under
`pg_advisory_lock`, tracked in `<schema>.schema_migrations` (version, name,
sha256 checksum). Editing an applied file is refused (add a new migration).
Statements that target another schema (`alter table public.orders …`,
`grant … on schema public`, `insert into core.…`), `CREATE EXTENSION`, roles,
`SET ROLE` and `SET search_path` are refused unless explicitly allowed
(`--allow-schema`, `--allow-extensions`, `--allow-roles`). `--role guests_owner`
runs each file as the module's owner role. Programmatic API: `migrate({ db,
schema, files })`, `loadMigrationFiles(dir)`, `checkSchemaScope(sql, schema)`,
`connectPg(url)`.

---

## Orders: extending a hold (0.3.1)

`core.orders.extendHold!(id, { ttl_seconds })` (`POST /v1/orders/{id}/hold/extend`,
`orders:write`, Idempotency-Key): moves a `held` order's `hold.expires_at` to
now + ttl (30–3600 s), never past `created_at` + 24 h (30 days for
`scheduled`). `CONFLICT` (`details.reason` `at_cap` | `expired`) or
`INVALID_TRANSITION` (not held). On the hub only the client that created the
held order may extend it (`FORBIDDEN not_hold_owner`). Create short holds
(e.g. 5 min) and extend while a card is being taken.

`payments.recordExternal` (hub, 0.3.1): `amount_cents` must be ≤ the order's
`amount_due_cents` (422 `exceeds_amount_due`); `collection: "terminal"` is
only accepted from the device principal whose id is the order's
`source.device_id` (403 `device_mismatch`). Set `source.device_id` to the
device client id when a kiosk/terminal creates the order. Tips: 0.3.1
`amount_due_cents` is the FOOD balance only ((total − totals.tip) − Σ
captured `amount_cents`); tips never reduce it. A tender's `tip_cents` ≤ its
own `amount_cents`, and Σ tips ≤ Σ food paid (`MAX_TIP_RATIO` = 1,
`checkTenderAmounts`); pay the order's pre-set tip as `tip_cents` with the
food. Adapters must compute `amount_due_cents` the same way. Tenders for one order are serialized (a concurrent second one
gets 409 `tender_in_progress`, retryable).

## 0.3.2 (additive)

**On-behalf-of device pairing.** Modules never hold `devices:pair`. With the
module client token and a staff token from `createHubLogin` (minted for that
same client):

```ts
const pairing = await core.devices.createPairingOnBehalf!({
  staffToken, // the signed-in manager's hub staff token
  kind: "board",
  location_id,
  name: "Menu TV",
});
await core.devices.revokeOnBehalf!(deviceId, { staffToken });
```

The hub verifies the staff token (aud `openpizza:staff:<client_id>`, same
tenant), re-reads the member (active, owner/manager per
`ON_BEHALF_PAIRING_ROLES`, works at the location) and the kind
(`MODULE_PAIRABLE_DEVICE_KINDS`: kiosk → kiosk/board, boards → board,
workforce → clock, backofhouse → kds; terminals never). 403
`details.reason`: `module_client_required` | `device_kind_not_allowed` |
`staff_token_invalid` | `staff_role_not_allowed` |
`staff_location_not_allowed`. MockCore implements both (it does not verify
signatures: pass a staff id or any JWT with `op_staff`; rules use
`createMockCore({ module })`). New device kind `clock` (workforce time clock:
roster + PIN, no orders or payments).

**Amount due is food only everywhere.** MockCore now creates orders with
`amount_due_cents` = total − tip (it included the tip at creation), and a COD
`Delivery.amount_due_cents` is the order's food balance (tip in `tip_cents`).

**Refund ids.** `Payment.refunds[]` = `{ id, amount_cents, at, processor_ref,
reason }` (optional for older backends). `payment.refunded` data is the
Payment plus `refund` (the refund this event is about): dedupe on
`data.refund.id`. `sim.refund(paymentId, amount, { processor_ref, reason })`.

**Per-line fire/void.** `OrderLine.fired_at`, `voided_at`, `status_at_void`
(optional). Void after fire = `fired_at` set before `voided_at`. MockCore fires
lines when the order reaches the kitchen; `sim.voidLine(orderId, lineId)`.

**RLS: `core.claim_has_scope(scope)`** (migration 0005 + standalone helpers):
`(select core.claim_has_scope('boards:pairing'))` replaces
`(select core.scope_matches(core.claim_scopes(), 'boards:pairing'))`. Token
scopes only (no `tid` needed); `core.has_scope(scope)` also requires `tid`.

## 0.3.3 (additive)

- `revokeOnBehalf` only for devices the same module paired (404 otherwise);
  console-paired devices only for an owner (403 `owner_required`). The hub
  authorises the module client + staff token before looking the device up.
- On-behalf pairing is capped at `ON_BEHALF_PAIRING_MAX_PER_HOUR` (20) per
  staff member per module (429).
- `core.staff.roster!({ location_id })` (`GET /v1/staff/roster`, scope
  `staff:roster`): active staff as `StaffRosterEntry` (`id, name,
display_name, roles, location_ids, has_pin`; no contact info). `clock`
  devices hold `staff:roster`, not `staff:read`.
- `core.claim_has_scope(scope)` returns false on malformed claims (migration
  0006).
- New core helpers reach existing module roles: helpers are tagged
  `openpizza:module-helper` and `core.grant_module_helpers()` (migration 0007) grants them to `mod_*` / `*_owner` roles; `openpizza-migrate` runs it
  after every `up` (`grantModuleHelpers(db)` from `@openpizza/core/migrate`).
- `core.devices.revokeOwn!(deviceId)` (`POST /v1/devices/{id}/revoke/own`):
  a module client revokes a device IT paired (on behalf), no staff token and
  no `devices:*` scope; devices of another module or the console → 403
  `not_own_device`. Audited as the module client.

## Adapters and conformance

`PosAdapter` (alias `CommerceAdapter`) maps a commerce source (POS, Square,
Clover, Toast) onto the contract. Optional methods are optional capabilities
and must match `capabilities()`. Register with `createAdapterRegistry()`.

```ts
// square.conformance.test.ts
import { describePosAdapterConformance } from "@openpizza/core/conformance";
describePosAdapterConformance({
  name: "square sandbox",
  adapter: () => createSquareAdapter(),
  context: () => ({ tenant_id, connection }),
  allowWrites: false, // true also exercises create/cancel idempotency
  sampleWebhook: () => loadSignedFixture(),
});
```

It checks capabilities against implemented methods, schema validity of
locations/menu/orders/customers/staff, tenant scoping, pagination, totals
invariants (`orderViolations`), `NOT_FOUND` problems, server-side quotes,
webhook normalization and backfill. `createMockPosAdapter(mockCore)` is the
reference implementation and passes it.

---

## API index

- **contract**: `TenantSchema`, `LocationSchema` (+ `HoursSchema`,
  `DayHoursSchema`, `SpecialHoursSchema`, `JurisdictionSchema`,
  `DeliveryZoneSchema`, `FulfillmentSettingsSchema`, `PricingSettingsSchema`),
  `MenuSchema` (+ `MenuCategorySchema`, `MenuItemSchema`, `ItemSizeSchema`,
  `ModifierGroupSchema`, `ModifierSchema`, `AvailabilitySchema`,
  `AllergenInfoSchema`, `US_ALLERGENS`, `EU_ALLERGENS`, `PLACEMENTS`,
  `MODIFIER_ROLES`, `HALF_PRICING_RULES`), cart inputs (`CartLineInputSchema`,
  `AdjustmentInputSchema`, `FulfillmentRequestSchema`, `TipInputSchema`),
  `OrderSchema` (+ `OrderLineSchema`, `AdjustmentSchema`, `OrderTotalsSchema`,
  `TenderSchema`, `HoldSchema`, `OrderCreateInputSchema`,
  `OrderCancelInputSchema`, `OrderListQuerySchema`, `FULFILLMENT_STATUSES`,
  `PAYMENT_STATUSES`, `canTransition`, `fromPosOrderStatus`, `fromPosChannel`),
  `QuoteRequestSchema`, `QuoteSchema`, `PaymentSchema`,
  `ExternalTenderInputSchema`, `CustomerSchema`, `CustomerUpsertInputSchema`,
  `StaffMemberSchema`, `DrawerSessionSchema`, `DeliverySchema`,
  `DailySalesSchema`, `SalesSummarySchema`, `CapabilitiesSchema`,
  `EntitlementsSchema`, `ModuleManifestSchema`, `ProblemSchema`, `problem()`,
  `ProblemError`, `ERROR_CODES`, `openEnum()`, `pageOf()`.
- **pricing**: `priceCart`, `priceCartOrThrow`, `placementPriceCents`,
  `matchDeliveryZone`, `totalsViolations`, `orderViolations`.
- **events**: `EVENT_CATALOG`, `EVENT_TYPES`, `createEvent`, `parseEvent`,
  `isEvent`, `matchesEventType`, `signWebhook`, `webhookHeaders`, `signEvent`,
  `verifyWebhook`, `verifyAndParseEvent`, `generateWebhookSecret`,
  `createMemoryInbox`, `dedupe`, `retryDelaySeconds`.
- **auth**: `ROLES`, `ROLE_SCOPES`, `CORE_SCOPES`, `hasScopes`,
  `missingScopes`, `scopesForRoles`, `requireScopes`, `requireLocation`,
  `CoreTokenClaimsSchema`, `principalFromClaims`, `createCoreTokenVerifier`,
  `verifyCoreToken`, `signCoreToken`, `bearerToken`,
  `createClientCredentialsTokenSource`, `generateSigningKey`, `toJwks`, `MODULE_IDS`,
  `MODULE_SCHEMAS`, `isModuleEnabled`, `moduleLimit`.
- **money**: `allocate`, `splitEvenly`, `applyBps`, `roundHalfUp`,
  `formatMoney`, `toMinorUnits`, `fromMinorUnits`, `currencyExponent`.
- **units**: `UNITS`, `UnitSchema`, `convert`, `toBase`, `dimensionOf`,
  `roundQty`.
- **hours**: `isOpenAt`, `nextOpenAt`, `currentWindow`, `isOpenThrough`,
  `hoursForService`, `businessDate`, `localParts`, `zonedTimeToUtc`.
- **ids**: `uuidv5`, `externalUuid`, `ulid`, `randomId`, `stableHash`.
- **client**: `CoreClient`, `createHttpCoreClient`, `V1_ROUTES`, `HUB_ROUTES`,
  `paginate`, `listAll`.
- **mock**: `createMockCore`, `createMockPosAdapter`, `DEMO_*` ids.
- **adapters**: `PosAdapter`, `AdapterContext`, `createAdapterRegistry`.
- **conformance**: `describePosAdapterConformance`.
- **migrate**: `migrate`, `planMigrations`, `checkSchemaScope`,
  `loadMigrationFiles`, `coreMigrationsDir`, `connectPg`, `runCli`.
