-- ============================================================================
-- core 0008 (0.3.4, defense in depth): core.grant_module_helpers() no longer
-- trusts the `openpizza:module-helper` tag alone.
--
-- Grants EXECUTE to module roles (mod_* / *_owner) only on:
--   1. the explicit ALLOWLIST below (core's public RLS helpers, including its
--      SECURITY DEFINER membership helpers), or
--   2. a function tagged `openpizza:module-helper` that is NOT on the hub
--      floor and is NOT SECURITY DEFINER.
-- The FLOOR (hub internals: emit, append_event, scopes_cover,
-- event_read_scope, event_type_matches, grant_module_helpers,
-- lock_hub_internals) is never granted, whatever its comment says. A
-- mis-tagged floor function is also refused loudly by the hub's
-- core.lock_hub_internals() (hub migration 1009).
-- ============================================================================

create or replace function core.grant_module_helpers()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  allow oid[] := array[]::oid[];
  sig text;
  fn record;
  r record;
  n integer := 0;
  floor_names constant text[] := array[
    'emit', 'append_event', 'scopes_cover', 'event_read_scope',
    'event_type_matches', 'grant_module_helpers', 'lock_hub_internals'
  ];
begin
  foreach sig in array array[
    'core.claims()',
    'core.claim_tenant_id()',
    'core.claim_scopes()',
    'core.claim_array(text)',
    'core.claim_has_scope(text)',
    'core.current_user_id()',
    'core.current_tenant_ids()',
    'core.has_scope(text)',
    'core.has_scope(uuid, text)',
    'core.has_tenant_role(uuid, text[])',
    'core.is_member(uuid)',
    'core.is_platform_admin()',
    'core.is_tenant_member(uuid)',
    'core.module_enabled(uuid, text)',
    'core.scope_act(text)',
    'core.scope_canon_res(text)',
    'core.scope_grants(text, text)',
    'core.scope_matches(text[], text)',
    'core.scope_res(text)',
    'core.tenant_ids_with_role(text[])',
    'core.tenant_ids_with_scope(text)',
    'core.user_roles(uuid)'
  ] loop
    if pg_catalog.to_regprocedure(sig) is not null then
      allow := allow || pg_catalog.to_regprocedure(sig)::oid;
    end if;
  end loop;

  for r in
    select rolname from pg_catalog.pg_roles
     where not rolsuper
       and (rolname ~ '^mod_[a-z][a-z0-9_]*$' or rolname ~ '^[a-z][a-z0-9_]*_owner$')
       and pg_catalog.has_schema_privilege(rolname, 'core', 'USAGE')
  loop
    for fn in
      select p.oid::pg_catalog.regprocedure::text as sig
        from pg_catalog.pg_proc p
        join pg_catalog.pg_namespace ns on ns.oid = p.pronamespace
       where ns.nspname = 'core'
         and not (p.proname = any (floor_names))
         and (
           p.oid = any (allow)
           or (
             pg_catalog.obj_description(p.oid, 'pg_proc') like 'openpizza:module-helper%'
             and not p.prosecdef
           )
         )
    loop
      execute pg_catalog.format('grant execute on function %s to %I', fn.sig, r.rolname);
      n := n + 1;
    end loop;
  end loop;
  return n;
end;
$$;
comment on function core.grant_module_helpers() is
  'openpizza:internal: grants EXECUTE on allowlisted / tagged non-definer core helpers to module roles (run by openpizza-migrate)';
revoke all on function core.grant_module_helpers() from public;
do $$
declare
  r text;
begin
  foreach r in array array['anon', 'authenticated', 'service_role'] loop
    if exists (select from pg_catalog.pg_roles where rolname = r) then
      execute pg_catalog.format('revoke all on function core.grant_module_helpers() from %I', r);
    end if;
  end loop;
end;
$$;
