-- ============================================================================
-- core 0006 (0.3.3)
--
-- 1. core.claim_has_scope(scope) never raises: malformed `request.jwt.claims`
--    (not JSON, not an object, `scope` not a string) → false. Still no row
--    argument: use it as `(select core.claim_has_scope('x'))` (once per
--    statement). plpgsql (for the exception handler), no SET clause.
-- 2. Role scope `staff:roster` for managers (owners have `*`), matching the
--    TS ROLE_SCOPES (0.3.3 CORE_SCOPES).
-- ============================================================================

create or replace function core.claim_has_scope(required_scope text)
returns boolean
language plpgsql
stable
as $$
declare
  raw text;
  c jsonb;
begin
  raw := pg_catalog.current_setting('request.jwt.claims', true);
  if raw is null or raw = '' then
    return false;
  end if;
  begin
    c := raw::jsonb;
  exception when others then
    return false;
  end;
  if pg_catalog.jsonb_typeof(c) is distinct from 'object'
     or pg_catalog.jsonb_typeof(c -> 'scope') is distinct from 'string' then
    return false;
  end if;
  return coalesce(
    core.scope_matches(pg_catalog.string_to_array(c ->> 'scope', ' '), required_scope),
    false
  );
end;
$$;

revoke all on function core.claim_has_scope(text) from public;
do $$
declare
  r text;
begin
  foreach r in array array['authenticated', 'service_role'] loop
    if exists (select from pg_roles where rolname = r) then
      execute format('grant execute on function core.claim_has_scope(text) to %I', r);
    end if;
  end loop;
end;
$$;

insert into core.role_scopes (role, scope) values ('manager', 'staff:roster')
on conflict do nothing;
