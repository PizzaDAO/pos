-- ============================================================================
-- @openpizza/core 0.3.0: new role → scope defaults (additive; mirrors
-- ROLE_SCOPES in src/auth/roles.ts, checked by contract.test.ts).
--
-- - manager gets the 0.3.0 core scopes (directory, devices, staff PIN verify,
--   customer auth, realtime, notifications, providers, tips).
-- - kitchen gets backofhouse:read|write (`kitchen` module id is a deprecated
--   alias of `backofhouse`; both scope spellings are honoured).
-- ============================================================================

insert into core.role_scopes (role, scope) values
  ('manager', 'directory:read'),
  ('manager', 'devices:read'),
  ('manager', 'devices:write'),
  ('manager', 'staff:pin_verify'),
  ('manager', 'customers:auth'),
  ('manager', 'realtime:publish'),
  ('manager', 'realtime:subscribe'),
  ('manager', 'notifications:send'),
  ('manager', 'providers:read'),
  ('manager', 'providers:write'),
  ('manager', 'tips:read'),
  ('kitchen', 'backofhouse:read'),
  ('kitchen', 'backofhouse:write'),
  -- Literal-only scopes (never covered by a wildcard, see below).
  ('owner', 'orders:discount'),
  ('owner', 'orders:release_unpaid'),
  ('manager', 'orders:discount'),
  ('manager', 'orders:release_unpaid')
on conflict do nothing;

-- Literal-only scopes: `*`, `orders:*`, `*:write` … never satisfy them; they
-- must be granted by name (mirrors LITERAL_SCOPES / grants() in TS).
create or replace function core.scope_matches(granted text[], required text)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select case
    when required in ('orders:discount', 'orders:place_direct', 'orders:release_unpaid')
      then required = any (granted)
    else exists (
      select 1
      from unnest(granted) as g(s)
      where g.s = '*'
         or g.s = required
         or (split_part(g.s, ':', 2) = '*' and split_part(g.s, ':', 1) = split_part(required, ':', 1))
         or (split_part(g.s, ':', 1) = '*' and split_part(g.s, ':', 2) = split_part(required, ':', 2))
         or (split_part(g.s, ':', 2) = split_part(required, ':', 2)
             and split_part(required, ':', 1) like split_part(g.s, ':', 1) || '.%')
    )
  end;
$$;
