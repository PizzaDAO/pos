-- ============================================================================
-- @openpizza/core 0.3.0 (review): SQL scope matching == TS `hasScopes`.
--
-- core.scope_grants(granted, required) mirrors `grants()` in
-- src/auth/roles.ts exactly (checked over a generated grid in
-- src/auth/scope-parity.test.ts):
--   - exact match always grants;
--   - LITERAL scopes (orders:discount, orders:place_direct,
--     orders:release_unpaid, staff:set_pin, devices:pair) only by name;
--   - `*` grants everything else;
--   - resource/action split at the LAST ':'; `kitchen` ≡ `backofhouse`;
--   - `<res>:*`, `*:<act>`, and `<res>:<act>` covering `<res>.<sub>:<act>`
--     (starts_with, not LIKE, so `_`/`%` in names are literal).
-- Also seeds the two new literal scopes for owner + manager.
-- ============================================================================

create or replace function core.scope_res(s text)
returns text
language sql
immutable
set search_path = ''
as $$
  select case
    when strpos(s, ':') = 0 then s
    else left(s, length(s) - length(substring(s from '[^:]*$')) - 1)
  end;
$$;

create or replace function core.scope_act(s text)
returns text
language sql
immutable
set search_path = ''
as $$
  select case when strpos(s, ':') = 0 then '' else substring(s from '[^:]*$') end;
$$;

create or replace function core.scope_canon_res(r text)
returns text
language sql
immutable
set search_path = ''
as $$
  select case when r = 'kitchen' then 'backofhouse' else r end;
$$;

create or replace function core.scope_grants(granted text, required text)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select case
    when granted = required then true
    when required in ('orders:discount', 'orders:place_direct', 'orders:release_unpaid',
                      'staff:set_pin', 'devices:pair') then false
    when granted = '*' then true
    else (
      with p as (
        select core.scope_canon_res(core.scope_res(granted)) as gr,
               core.scope_act(granted) as ga,
               core.scope_canon_res(core.scope_res(required)) as rr,
               core.scope_act(required) as ra
      )
      select (gr = rr and ga = ra)
          or (ga = '*' and gr = rr)
          or (gr = '*' and ga = ra)
          or (ga = ra and starts_with(rr, gr || '.'))
        from p
    )
  end;
$$;

create or replace function core.scope_matches(granted text[], required text)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select exists (
    select 1 from unnest(granted) as g(s)
     where length(g.s) > 0 and core.scope_grants(g.s, required)
  );
$$;

insert into core.role_scopes (role, scope) values
  ('owner', 'staff:set_pin'),
  ('owner', 'devices:pair'),
  ('manager', 'staff:set_pin'),
  ('manager', 'devices:pair')
on conflict do nothing;
