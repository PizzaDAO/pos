-- ============================================================================
-- core 0004 (0.3.1): RLS helpers that do not run per row.
--
-- SECURITY DEFINER helpers called with a per-row argument
-- (core.is_tenant_member(tenant_id), core.has_scope(tenant_id, …)) cannot be
-- inlined and run once PER ROW (measured ~30 µs / ~250 µs per row; 21k rows
-- took 5 s). The fast pattern compares the row's tenant to values computed
-- ONCE per statement (an initplan / hashed subplan):
--
--   using (
--     tenant_id = (select core.claim_tenant_id())             -- machine/JWT callers
--     or tenant_id in (select core.current_tenant_ids())     -- members (shared mode)
--   )
--   with check (tenant_id = (select core.claim_tenant_id()) and (select core.has_scope('guests:write')))
--
-- New here:
--   core.claims(), core.claim_tenant_id(), core.claim_scopes()  -- no SET clause: inlinable
--   core.has_scope(scope text)                 -> boolean       -- claim tenant + claim scopes, no row arg
--   core.tenant_ids_with_role(roles text[])    -> setof uuid    -- tenants where the caller holds a role
--   core.tenant_ids_with_scope(scope text)     -> setof uuid    -- tenants where the caller has a scope
-- and core's own policies rewritten to that pattern, with separate
-- insert/update/delete policies instead of `for all` (a `for all` policy is
-- OR'ed into every SELECT).
-- ============================================================================

-- Inlinable claim readers: plain SQL, STABLE, no SET clause (a SET clause
-- prevents inlining). Every reference is schema-qualified / built-in.
create or replace function core.claims()
returns jsonb
language sql
stable
as $$
  select coalesce(nullif(pg_catalog.current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb);
$$;

create or replace function core.claim_tenant_id()
returns uuid
language sql
stable
as $$
  select case
    when (core.claims() ->> 'tid') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      then (core.claims() ->> 'tid')::uuid
  end;
$$;

create or replace function core.claim_scopes()
returns text[]
language sql
stable
as $$
  select coalesce(pg_catalog.string_to_array(nullif(core.claims() ->> 'scope', ''), ' '), '{}'::text[]);
$$;

-- Scope check against the token's own tenant: no row argument, so
-- `(select core.has_scope('x'))` is evaluated once per statement.
create or replace function core.has_scope(required_scope text)
returns boolean
language sql
stable
as $$
  select core.claim_tenant_id() is not null and core.scope_matches(core.claim_scopes(), required_scope);
$$;

create or replace function core.tenant_ids_with_role(allowed_roles text[])
returns setof uuid
language sql
stable
security definer
set search_path = ''
as $$
  select m.tenant_id from public.memberships m
   where m.user_id = auth.uid() and m.role::text = any (allowed_roles)
  union
  select g.tenant_id from core.member_grants g
   where g.user_id = auth.uid() and g.role = any (allowed_roles);
$$;

create or replace function core.tenant_ids_with_scope(required_scope text)
returns setof uuid
language sql
stable
security definer
set search_path = ''
as $$
  select core.claim_tenant_id()
   where core.claim_tenant_id() is not null
     and core.scope_matches(core.claim_scopes(), required_scope)
  union
  select t.tenant_id
    from (
      select m.tenant_id, m.role::text as role from public.memberships m where m.user_id = auth.uid()
      union all
      select g.tenant_id, g.role from core.member_grants g where g.user_id = auth.uid()
    ) t
    join core.role_scopes rs on rs.role = t.role
   group by t.tenant_id
  having core.scope_matches(array_agg(rs.scope), required_scope);
$$;

-- ---------------------------------------------------------------------------
-- core's own policies, rewritten (once-per-statement helpers; no `for all`).
-- ---------------------------------------------------------------------------

drop policy if exists member_grants_select on core.member_grants;
create policy member_grants_select on core.member_grants
  for select using (
    user_id = (select auth.uid())
    or tenant_id in (select core.tenant_ids_with_role(array['owner', 'manager']))
    or (select core.is_platform_admin())
  );

drop policy if exists member_grants_write on core.member_grants;
drop policy if exists member_grants_insert on core.member_grants;
create policy member_grants_insert on core.member_grants
  for insert with check (
    tenant_id in (select core.tenant_ids_with_role(array['owner', 'manager']))
    or (select core.is_platform_admin())
  );
drop policy if exists member_grants_update on core.member_grants;
create policy member_grants_update on core.member_grants
  for update using (
    tenant_id in (select core.tenant_ids_with_role(array['owner', 'manager']))
    or (select core.is_platform_admin())
  ) with check (
    tenant_id in (select core.tenant_ids_with_role(array['owner', 'manager']))
    or (select core.is_platform_admin())
  );
drop policy if exists member_grants_delete on core.member_grants;
create policy member_grants_delete on core.member_grants
  for delete using (
    tenant_id in (select core.tenant_ids_with_role(array['owner', 'manager']))
    or (select core.is_platform_admin())
  );

drop policy if exists tenant_modules_select on core.tenant_modules;
create policy tenant_modules_select on core.tenant_modules
  for select using (
    tenant_id = (select core.claim_tenant_id())
    or tenant_id in (select core.current_tenant_ids())
    or (select core.is_platform_admin())
  );

revoke all on function core.has_scope(text) from public;
revoke all on function core.tenant_ids_with_role(text[]) from public;
revoke all on function core.tenant_ids_with_scope(text) from public;
-- Grant ONLY the new functions, by name. A blanket `grant … on all functions
-- in schema core` here would re-open hub-internal functions (core.emit,
-- core.append_event, core.scopes_cover) on databases where the hub's
-- migrations already ran (upgrade path).
do $$
declare
  r text;
begin
  foreach r in array array['authenticated', 'service_role'] loop
    if exists (select from pg_roles where rolname = r) then
      execute format('grant execute on function core.has_scope(text) to %I', r);
      execute format('grant execute on function core.tenant_ids_with_role(text[]) to %I', r);
      execute format('grant execute on function core.tenant_ids_with_scope(text) to %I', r);
    end if;
  end loop;
end;
$$;
