-- ============================================================================
-- core 0005 (0.3.2): core.claim_has_scope(scope) for module RLS policies.
--
-- Modules wrote `(select core.scope_matches(core.claim_scopes(), 'boards:pairing'))`.
-- This is the same check as one call, with no row argument, so it runs
-- ONCE per statement when wrapped in `(select …)` (an initplan):
--
--   using ((select core.claim_has_scope('boards:pairing')))
--
-- Difference from core.has_scope(scope): has_scope also requires a valid
-- `tid` claim (use it with `tenant_id = (select core.claim_tenant_id())`);
-- claim_has_scope checks the token's scopes only. Literal scopes
-- (devices:pair, orders:discount …) are never covered by wildcards here
-- either (core.scope_matches).
-- ============================================================================

create or replace function core.claim_has_scope(required_scope text)
returns boolean
language sql
stable
as $$
  select core.scope_matches(core.claim_scopes(), required_scope);
$$;

revoke all on function core.claim_has_scope(text) from public;
-- Grant ONLY this function, by name (never `all functions in schema core`:
-- that would re-open hub internals on the upgrade path).
do $$
declare
  r text;
begin
  foreach r in array array['authenticated', 'service_role'] loop
    if exists (select from pg_roles where rolname = r) then
      execute format('grant execute on function core.claim_has_scope(text) to %I', r);
    end if;
  end loop;
end;
$$;
