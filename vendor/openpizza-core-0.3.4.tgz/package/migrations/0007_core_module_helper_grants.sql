-- ============================================================================
-- core 0007 (0.3.3): module roles get EXECUTE on NEW core helpers.
--
-- provision_module_role.sql grants EXECUTE on the core functions that exist
-- WHEN IT RUNS. Helpers added later (core.claim_has_scope, migration 0005)
-- were therefore not executable by already-provisioned `mod_<module>` /
-- `<module>_owner` roles, and module RLS policies using them failed with
-- "permission denied for function".
--
-- Fix:
--   * public RLS helpers are tagged `comment on function … is
--     'openpizza:module-helper: …'` (hub internals stay `openpizza:internal`);
--   * core.grant_module_helpers() grants EXECUTE on every tagged core function
--     to every module role (`mod_*` / `*_owner` with USAGE on schema core);
--   * openpizza-migrate calls it after every `up` (like lock_hub_internals),
--     provision_module_role.sql calls it, and this migration runs it once,
--     retroactively covering 0005's claim_has_scope on upgraded databases.
--
-- New public core helpers: tag them in the migration that creates them; the
-- next `openpizza-migrate up` grants them. (0005 itself is not edited: applied
-- files are checksummed.)
-- ============================================================================

do $$
declare
  f text;
begin
  foreach f in array array[
    'core.claims()',
    'core.claim_tenant_id()',
    'core.claim_scopes()',
    'core.claim_has_scope(text)',
    'core.current_user_id()',
    'core.current_tenant_ids()',
    'core.has_scope(text)',
    'core.has_scope(uuid, text)',
    'core.has_tenant_role(uuid, text[])',
    'core.is_member(uuid)',
    'core.is_platform_admin()',
    'core.is_tenant_member(uuid)',
    'core.module_enabled(uuid, text)',
    'core.scope_act(text)',
    'core.scope_canon_res(text)',
    'core.scope_grants(text, text)',
    'core.scope_matches(text[], text)',
    'core.scope_res(text)',
    'core.tenant_ids_with_role(text[])',
    'core.tenant_ids_with_scope(text)',
    'core.user_roles(uuid)',
    'core.claim_array(text)'
  ] loop
    continue when pg_catalog.to_regprocedure(f) is null;
    execute pg_catalog.format(
      'comment on function %s is %L', f,
      'openpizza:module-helper: RLS helper for module policies'
    );
  end loop;
end;
$$;

-- SECURITY DEFINER so a migrate run can re-grant even when the connecting
-- role does not own core's functions; EXECUTE revoked from everyone else.
create or replace function core.grant_module_helpers()
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  fn record;
  r record;
  n integer := 0;
begin
  for r in
    select rolname from pg_catalog.pg_roles
     where not rolsuper
       and (rolname ~ '^mod_[a-z][a-z0-9_]*$' or rolname ~ '^[a-z][a-z0-9_]*_owner$')
       and pg_catalog.has_schema_privilege(rolname, 'core', 'USAGE')
  loop
    for fn in
      select p.oid::pg_catalog.regprocedure::text as sig
        from pg_catalog.pg_proc p
        join pg_catalog.pg_namespace ns on ns.oid = p.pronamespace
       where ns.nspname = 'core'
         and pg_catalog.obj_description(p.oid, 'pg_proc') like 'openpizza:module-helper%'
    loop
      execute pg_catalog.format('grant execute on function %s to %I', fn.sig, r.rolname);
      n := n + 1;
    end loop;
  end loop;
  return n;
end;
$$;
comment on function core.grant_module_helpers() is
  'openpizza:internal: grants EXECUTE on openpizza:module-helper functions to module roles (run by openpizza-migrate)';
revoke all on function core.grant_module_helpers() from public;
do $$
declare
  r text;
begin
  foreach r in array array['anon', 'authenticated', 'service_role'] loop
    if exists (select from pg_catalog.pg_roles where rolname = r) then
      execute pg_catalog.format('revoke all on function core.grant_module_helpers() from %I', r);
    end if;
  end loop;
end;
$$;

-- Retroactive: already-provisioned module roles get 0005's claim_has_scope
-- (and every other tagged helper) now.
select core.grant_module_helpers();
