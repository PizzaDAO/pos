-- ============================================================================
-- core STANDALONE bootstrap (0.3.1): the minimal stand-ins for the Supabase /
-- POS objects that core's migrations reference, for a PLAIN Postgres
-- (module test:pg, CI, or a module running on its own database).
--
--   roles  anon, authenticated, service_role (bypassrls)      -- if missing
--   auth.uid()            -> request.jwt.claims ->> 'sub' (uuid or null)  -- if missing
--   public.memberships     (id, user_id, tenant_id, role, created_at,
--                          unique (user_id, tenant_id))       -- POS shape
--   public.platform_admins (user_id, created_at)              -- POS shape
--
-- Idempotent. `openpizza-migrate up --core --standalone` applies this, then
-- core's migrations, then sql/standalone/core_helpers_jwt.sql. For tests that
-- want shared-mode semantics (insert members, then check RLS) apply this file
-- and run `openpizza-migrate up --core` instead.
--
-- NEVER apply to a Supabase project that hosts POS: it has the real tables.
-- The stub tables carry the comment 'openpizza:standalone-stub', which the
-- CLI uses to refuse --standalone on a real POS database.
-- ============================================================================

do $$
begin
  if not exists (select from pg_roles where rolname = 'anon') then
    create role anon nologin noinherit;
  end if;
  if not exists (select from pg_roles where rolname = 'authenticated') then
    create role authenticated nologin noinherit;
  end if;
  if not exists (select from pg_roles where rolname = 'service_role') then
    create role service_role nologin noinherit bypassrls;
  end if;
end;
$$;

create schema if not exists auth;

do $$
begin
  if to_regprocedure('auth.uid()') is null then
    execute $f$
      create function auth.uid() returns uuid language sql stable set search_path = '' as $b$
        select case
          when (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
               ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
            then (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')::uuid
        end;
      $b$
    $f$;
  end if;
end;
$$;
grant usage on schema auth to anon, authenticated, service_role;
grant execute on function auth.uid() to anon, authenticated, service_role;

create table if not exists public.memberships (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  tenant_id uuid not null,
  role text not null check (role in ('owner', 'manager', 'cashier', 'kitchen')),
  created_at timestamptz not null default now(),
  unique (user_id, tenant_id)
);
create index if not exists memberships_tenant_id_idx on public.memberships (tenant_id);

create table if not exists public.platform_admins (
  user_id uuid primary key,
  created_at timestamptz not null default now()
);

do $$
begin
  -- Mark only tables this file created (a real POS table has its own comment or none).
  if obj_description('public.memberships'::regclass, 'pg_class') is null then
    comment on table public.memberships is 'openpizza:standalone-stub';
  end if;
  if obj_description('public.platform_admins'::regclass, 'pg_class') is null then
    comment on table public.platform_admins is 'openpizza:standalone-stub';
  end if;
end;
$$;
