-- ============================================================================
-- core helpers, STANDALONE MODE (a module running on its own database).
--
-- Same function names/signatures as migrations/0001_core_rls_helpers.sql, so
-- module RLS policies are portable byte-for-byte. Reads ONLY JWT claims
-- (request.jwt.claims), as set by PostgREST from a core-issued / OAuth token,
-- or by the module server per transaction:
--
--   {"sub": "<user or client id>", "tid": "<tenant uuid>",
--    "scope": "orders:read guests:admin", "op_roles": ["manager"],
--    "op_modules": ["guests"], "op_admin": false}
--
-- Apply once to the standalone database (requires the `auth.uid()` function,
-- present on any Supabase project). Do NOT apply to the shared project.
-- ============================================================================

create schema if not exists core;

-- 0.3.1: claim readers have no SET clause so the planner can inline them.
create or replace function core.claims() returns jsonb language sql stable as $$
  select coalesce(nullif(pg_catalog.current_setting('request.jwt.claims', true), '')::jsonb, '{}'::jsonb);
$$;

create or replace function core.claim_tenant_id() returns uuid language sql stable as $$
  select case
    when (core.claims() ->> 'tid') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      then (core.claims() ->> 'tid')::uuid
  end;
$$;

create or replace function core.claim_scopes() returns text[] language sql stable as $$
  select coalesce(pg_catalog.string_to_array(nullif(core.claims() ->> 'scope', ''), ' '), '{}'::text[]);
$$;

create or replace function core.claim_array(key text) returns text[] language sql stable set search_path = '' as $$
  select coalesce(array(select jsonb_array_elements_text(core.claims() -> key)), '{}'::text[]);
$$;

create or replace function core.current_user_id() returns uuid language sql stable set search_path = '' as $$
  select case
    when (core.claims() ->> 'sub') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      then (core.claims() ->> 'sub')::uuid
  end;
$$;

-- Same as migrations/0003 (TS hasScopes parity).
create or replace function core.scope_res(s text)
returns text
language sql
immutable
set search_path = ''
as $$
  select case
    when strpos(s, ':') = 0 then s
    else left(s, length(s) - length(substring(s from '[^:]*$')) - 1)
  end;
$$;

create or replace function core.scope_act(s text)
returns text
language sql
immutable
set search_path = ''
as $$
  select case when strpos(s, ':') = 0 then '' else substring(s from '[^:]*$') end;
$$;

create or replace function core.scope_canon_res(r text)
returns text
language sql
immutable
set search_path = ''
as $$
  select case when r = 'kitchen' then 'backofhouse' else r end;
$$;

create or replace function core.scope_grants(granted text, required text)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select case
    when granted = required then true
    when required in ('orders:discount', 'orders:place_direct', 'orders:release_unpaid',
                      'staff:set_pin', 'devices:pair') then false
    when granted = '*' then true
    else (
      with p as (
        select core.scope_canon_res(core.scope_res(granted)) as gr,
               core.scope_act(granted) as ga,
               core.scope_canon_res(core.scope_res(required)) as rr,
               core.scope_act(required) as ra
      )
      select (gr = rr and ga = ra)
          or (ga = '*' and gr = rr)
          or (gr = '*' and ga = ra)
          or (ga = ra and starts_with(rr, gr || '.'))
        from p
    )
  end;
$$;

create or replace function core.scope_matches(granted text[], required text)
returns boolean
language sql
immutable
set search_path = ''
as $$
  select exists (
    select 1 from unnest(granted) as g(s)
     where length(g.s) > 0 and core.scope_grants(g.s, required)
  );
$$;

create or replace function core.is_platform_admin() returns boolean language sql stable set search_path = '' as $$
  select coalesce((core.claims() ->> 'op_admin')::boolean, false);
$$;

create or replace function core.user_roles(target_tenant_id uuid) returns text[] language sql stable set search_path = '' as $$
  select case when core.claim_tenant_id() = target_tenant_id then core.claim_array('op_roles') else '{}'::text[] end;
$$;

create or replace function core.is_tenant_member(target_tenant_id uuid) returns boolean language sql stable set search_path = '' as $$
  select coalesce(core.claim_tenant_id() = target_tenant_id, false);
$$;

create or replace function core.is_member(target_tenant_id uuid) returns boolean language sql stable set search_path = '' as $$
  select core.is_tenant_member(target_tenant_id);
$$;

create or replace function core.has_tenant_role(target_tenant_id uuid, allowed_roles text[])
returns boolean language sql stable set search_path = '' as $$
  select core.user_roles(target_tenant_id) && allowed_roles;
$$;

create or replace function core.has_scope(target_tenant_id uuid, required_scope text)
returns boolean language sql stable set search_path = '' as $$
  select coalesce(core.claim_tenant_id() = target_tenant_id and core.scope_matches(core.claim_scopes(), required_scope), false);
$$;

create or replace function core.current_tenant_ids() returns setof uuid language sql stable set search_path = '' as $$
  select core.claim_tenant_id() where core.claim_tenant_id() is not null;
$$;

create or replace function core.module_enabled(target_tenant_id uuid, module text)
returns boolean language sql stable set search_path = '' as $$
  select coalesce(core.claim_tenant_id() = target_tenant_id and module = any(core.claim_array('op_modules')), false);
$$;

-- 0.3.1: once-per-statement helpers (see migrations/0004 and README "RLS policy pattern").
create or replace function core.has_scope(required_scope text)
returns boolean language sql stable as $$
  select core.claim_tenant_id() is not null and core.scope_matches(core.claim_scopes(), required_scope);
$$;

-- 0.3.2 (migrations/0005, 0006): token scopes only, no tid requirement;
-- malformed claims → false (never raises).
create or replace function core.claim_has_scope(required_scope text)
returns boolean language plpgsql stable as $$
declare
  raw text;
  c jsonb;
begin
  raw := pg_catalog.current_setting('request.jwt.claims', true);
  if raw is null or raw = '' then
    return false;
  end if;
  begin
    c := raw::jsonb;
  exception when others then
    return false;
  end;
  if pg_catalog.jsonb_typeof(c) is distinct from 'object'
     or pg_catalog.jsonb_typeof(c -> 'scope') is distinct from 'string' then
    return false;
  end if;
  return coalesce(
    core.scope_matches(pg_catalog.string_to_array(c ->> 'scope', ' '), required_scope),
    false
  );
end;
$$;

create or replace function core.tenant_ids_with_role(allowed_roles text[])
returns setof uuid language sql stable set search_path = '' as $$
  select core.claim_tenant_id() where core.claim_tenant_id() is not null and core.claim_array('op_roles') && allowed_roles;
$$;

create or replace function core.tenant_ids_with_scope(required_scope text)
returns setof uuid language sql stable set search_path = '' as $$
  select core.claim_tenant_id() where core.has_scope(required_scope);
$$;

revoke all on all functions in schema core from public;
do $$
declare r text;
begin
  foreach r in array array['authenticated', 'service_role'] loop
    if exists (select from pg_roles where rolname = r) then
      execute format('grant usage on schema core to %I', r);
      execute format('grant execute on all functions in schema core to %I', r);
    end if;
  end loop;
  -- 0.3.3: the grant helper is internal (never for app roles).
  if to_regprocedure('core.grant_module_helpers()') is not null then
    revoke all on function core.grant_module_helpers() from public;
    foreach r in array array['anon', 'authenticated', 'service_role'] loop
      if exists (select from pg_roles where rolname = r) then
        execute format('revoke all on function core.grant_module_helpers() from %I', r);
      end if;
    end loop;
  end if;
  -- 0.3.1: never re-open hub internals if the hub's migrations share this database.
  if to_regprocedure('core.lock_hub_internals()') is not null then
    perform core.lock_hub_internals();
  end if;
end;
$$;

-- 0.3.3: tag the standalone-only helper and grant the helper set to module roles.
comment on function core.claim_array(text) is
  'openpizza:module-helper: RLS helper for module policies';
do $$
begin
  if to_regprocedure('core.grant_module_helpers()') is not null then
    perform core.grant_module_helpers();
  end if;
end;
$$;
