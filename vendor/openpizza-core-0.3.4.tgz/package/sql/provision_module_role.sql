-- ============================================================================
-- Provision a module's database roles + schema (run ONCE per module by the
-- project owner, e.g. psql or the Supabase SQL editor). Not a migration: it
-- touches project-level objects (roles), which openpizza-migrate refuses.
--
--   psql "$DATABASE_URL" -v module=guests -v password='…' -f provision_module_role.sql
--   (or programmatically: provisionModuleRoleSql({ module, password }) from
--    @openpizza/core/migrate, which renders this same file)
--
-- 0.3.1: two roles (owner vs runtime), so the role the app connects as can
-- never ALTER/DROP its own tables or disable RLS:
--
--   <module>_owner  NOLOGIN; owns the schema and every table/function in it.
--                   Migrations run as it:
--                     openpizza-migrate up --schema guests --dir migrations --role guests_owner
--                   (the connecting admin is granted membership below).
--   mod_<module>    LOGIN (the module's DATABASE_URL); no ownership, only
--                   DML on the schema's tables (default privileges), USAGE on
--                   sequences, EXECUTE on the schema's functions and on core's
--                   helpers (never the hub internals). RLS applies to it.
-- ============================================================================

\set owner_role :module _owner
\set runtime_role mod_ :module

-- 1. Owner (no login; the admin can SET ROLE to it for migrations).
create role :"owner_role" nologin noinherit nobypassrls;
grant :"owner_role" to current_user;

-- 2. Runtime login role.
create role :"runtime_role" login password :'password' noinherit nobypassrls;

-- 3. Schema owned by the owner role.
create schema if not exists :"module" authorization :"owner_role";
grant usage on schema :"module" to :"runtime_role";

-- 4. Whatever the owner creates later is usable (not owned) by the runtime role.
alter default privileges for role :"owner_role" in schema :"module"
  grant select, insert, update, delete on tables to :"runtime_role";
alter default privileges for role :"owner_role" in schema :"module"
  grant usage, select on sequences to :"runtime_role";
alter default privileges for role :"owner_role" in schema :"module"
  grant execute on functions to :"runtime_role";

-- 5. Core helpers for both roles; hub internals stay closed.
grant usage on schema core to :"owner_role", :"runtime_role";
grant execute on all functions in schema core to :"owner_role", :"runtime_role";
-- Hub internals (functions tagged `openpizza:internal`) are revoked from
-- every module role when the hub is installed in this database.
-- 0.3.3: helpers added by LATER core migrations are granted by
-- core.grant_module_helpers() (openpizza-migrate runs it after every `up`).
do $$
begin
  if to_regprocedure('core.grant_module_helpers()') is not null then
    perform core.grant_module_helpers();
  end if;
  if to_regprocedure('core.lock_hub_internals()') is not null then
    perform core.lock_hub_internals();
  end if;
end;
$$;

-- 6. Explicitly nothing on public (POS): belt and braces.
revoke all on schema public from :"owner_role", :"runtime_role";

-- 7. Browser access (optional): expose the schema to PostgREST in project
--    settings, then grant table privileges to `authenticated` in the module's
--    own migrations (RLS still applies).
